const fs = require('fs');
const path = require('path');

function walk(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walk(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      const code = fs.readFileSync(fullPath, 'utf8');
      if (code.includes('profile')) {
        // Find if 'profile' is used as a variable but not destructured from useAuth or defined as a variable.
        const lines = code.split('\n');
        let usesUseAuth = false;
        let destructuresProfile = false;
        for (const line of lines) {
          if (line.includes('useAuth')) usesUseAuth = true;
          if (line.includes('useAuth') && line.includes('profile')) destructuresProfile = true;
        }
        if (usesUseAuth && !destructuresProfile) {
            // Check if profile is used elsewhere in the file
            const hasProfileUsage = code.match(/profile\b/g);
            if (hasProfileUsage && hasProfileUsage.length > 0) {
               console.log(fullPath);
            }
        }
      }
    }
  }
}

walk('src/pages');
walk('src/components');
