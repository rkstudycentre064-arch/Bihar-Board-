const fs = require('fs');
const files = [
  'src/pages/admin/AdminCMSPage.tsx',
  'src/pages/admin/AdminAddContentPage.tsx',
  'src/pages/admin/AdminTestsPage.tsx',
  'src/pages/public/ContentDetailPage.tsx'
];

for(const file of files) {
  if (fs.existsSync(file)) {
    let code = fs.readFileSync(file, 'utf-8');
    code = code.replace(/\\\`/g, '`');
    code = code.replace(/\\\$/g, '$'); // Just in case ${ was escaped as \${
    fs.writeFileSync(file, code);
  }
}
console.log("Fixed backticks");
