const fs = require('fs');

let code = fs.readFileSync('src/pages/admin/teacher-panel/AdminTeacherLayout.tsx', 'utf8');

const targetMenu = `    { id: 'settings', label: 'Settings', icon: Settings }
  ];`;

const replacementMenu = `    { 
      label: 'Website Ratings', icon: CheckCircle,
      sub: [
        { id: 'ratings_all', label: 'All Ratings' },
        { id: 'ratings_pending', label: 'Pending Reviews' }
      ]
    },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];`;

code = code.replace(targetMenu, replacementMenu);
fs.writeFileSync('src/pages/admin/teacher-panel/AdminTeacherLayout.tsx', code);
