const fs = require('fs');

let code = fs.readFileSync('src/pages/admin/AdminPanel.tsx', 'utf8');

// Add import
code = code.replace(
  "import { TeacherContent } from './teacher-panel/TeacherContent';",
  "import { TeacherContent } from './teacher-panel/TeacherContent';\nimport { AdminRatingsList } from './teacher-panel/AdminRatingsList';"
);

// Add cases
const casesTarget = `      case 'content_archived':
        return <TeacherContent filter={activeTab.split('_')[1]} />;`;

const casesReplacement = `      case 'content_archived':
        return <TeacherContent filter={activeTab.split('_')[1]} />;
      case 'ratings_all':
      case 'ratings_pending':
        return <AdminRatingsList filter={activeTab.split('_')[1]} />;`;

code = code.replace(casesTarget, casesReplacement);
fs.writeFileSync('src/pages/admin/AdminPanel.tsx', code);
