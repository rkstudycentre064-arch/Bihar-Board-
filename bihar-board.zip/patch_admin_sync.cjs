const fs = require('fs');

let code = fs.readFileSync('src/pages/admin/AdminPanel.tsx', 'utf8');

// Add useEffect import
code = code.replace(
  "import React, { useState } from 'react';",
  "import React, { useState, useEffect } from 'react';"
);

// Add firestore imports
code = code.replace(
  "import { useAuth } from '../../context/AuthContext';",
  "import { useAuth } from '../../context/AuthContext';\nimport { doc, setDoc } from 'firebase/firestore';\nimport { db } from '../../lib/firebase';"
);

// Sync to firestore if admin
const checkAdmin = `  if (profile?.role !== 'admin') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }`;

const checkAdminReplacement = `  useEffect(() => {
    if (profile?.role === 'admin' && profile.uid) {
      // Sync admin status to Firestore so Security Rules pass
      setDoc(doc(db, 'admins', profile.uid), { synced: true, role: 'admin' }, { merge: true }).catch(console.error);
    }
  }, [profile]);

  if (profile?.role !== 'admin') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }`;

code = code.replace(checkAdmin, checkAdminReplacement);
fs.writeFileSync('src/pages/admin/AdminPanel.tsx', code);
