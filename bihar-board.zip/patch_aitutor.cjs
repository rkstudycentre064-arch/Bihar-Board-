const fs = require('fs');

const code = `import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Brain, Send, Image as ImageIcon, Plus, Trash2, X, FileText, Calculator, Microscope, Edit3, Target, BookOpen, RefreshCw, HelpCircle, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { cn } from '../../lib/utils';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { createAIConversation, getUserAIConversations, getAIConversationMessages, addAIMessage, deleteAIConversation, AIConversation } from '../../db/ai';
import { getAuth } from 'firebase/auth';

export const AiTutorPage = () => {
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  
  // Conversations State
  const [conversations, setConversations] = useState<AIConversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<{id?: string, role: 'user' | 'model', content: string}[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [fetchingHistory, setFetchingHistory] = useState(true);
  
  // Image Upload State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user?.uid) {
      loadConversations();
    } else {
      setFetchingHistory(false);
    }
  }, [user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const loadConversations = async () => {
    if (!user?.uid) return;
    try {
      setFetchingHistory(true);
      const convos = await getUserAIConversations(user.uid);
      setConversations(convos);
      if (convos.length > 0) {
        await selectConversation(convos[0].id);
      } else {
        // Start a new conversation automatically if none exist
        startNewConversation();
      }
    } catch (error) {
      console.error("Error loading conversations:", error);
    } finally {
      setFetchingHistory(false);
    }
  };

  const selectConversation = async (id: string) => {
    if (!user?.uid) return;
    setCurrentConversationId(id);
    setLoading(true);
    try {
      const msgs = await getAIConversationMessages(user.uid, id);
      setMessages(msgs.map(m => ({ id: m.id, role: m.role, content: m.parts[0]?.text || '' })));
    } catch (error) {
      console.error("Error loading messages:", error);
    } finally {
      setLoading(false);
    }
  };

  const startNewConversation = () => {
    setCurrentConversationId(null);
    setMessages([
      { role: 'model', content: 'नमस्ते! मैं **BIHAR BOARD AI Tutor** हूँ।\\n\\n"कक्षा 9वीं से 12वीं तक आपकी पढ़ाई का स्मार्ट साथी"\\n\\nआप मुझसे गणित, विज्ञान या किसी भी विषय के बारे में पूछ सकते हैं।' }
    ]);
  };

  const handleDeleteConversation = async (id: string) => {
    try {
      await deleteAIConversation(id);
      const updated = conversations.filter(c => c.id !== id);
      setConversations(updated);
      if (currentConversationId === id) {
        if (updated.length > 0) {
          selectConversation(updated[0].id);
        } else {
          startNewConversation();
        }
      }
    } catch (err) {
      console.error("Delete failed", err);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSend = async (text: string = query) => {
    if (!text.trim() && !selectedImage) return;
    if (!user?.uid) return alert("Please login to use AI Tutor");
    
    const userText = text;
    const currentImage = selectedImage;
    
    setQuery("");
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    
    const newMessages = [...messages, { role: 'user' as const, content: userText }];
    setMessages(newMessages);
    setLoading(true);

    try {
      let convId = currentConversationId;
      
      // Create new conversation if needed
      if (!convId) {
        const title = userText.slice(0, 30) + (userText.length > 30 ? '...' : '') || 'New Chat';
        convId = await createAIConversation(user.uid, title, '', '');
        setCurrentConversationId(convId);
        setConversations(prev => [{ id: convId!, userId: user.uid, title, createdAt: new Date(), updatedAt: new Date() }, ...prev]);
        
        // Add the welcome message to the DB for history consistency
        await addAIMessage(convId, user.uid, 'model', messages[0].content);
      }
      
      // Save User Message to DB
      await addAIMessage(convId, user.uid, 'user', userText);

      // Call API
      const auth = getAuth();
      const token = await auth.currentUser?.getIdToken();

      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': \`Bearer \${token}\`
        },
        body: JSON.stringify({
          history: messages.filter(m => m.id !== undefined), // Only send historical actual messages, skip welcome if unsaved
          message: userText,
          imageBase64: currentImage
        })
      });

      if (!response.ok) {
        throw new Error("API Response Error");
      }

      const data = await response.json();
      const modelResponse = data.text;
      
      // Save Model Message to DB
      const msgId = await addAIMessage(convId, user.uid, 'model', modelResponse);
      
      setMessages(prev => [...prev, { id: msgId, role: 'model', content: modelResponse }]);

    } catch (error) {
      console.error("AI Chat Error:", error);
      setMessages(prev => [...prev, { role: 'model', content: 'क्षमा करें, कोई तकनीकी समस्या आ गई। कृपया थोड़ी देर बाद प्रयास करें।' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickAction = (action: string) => {
    handleSend(action);
  };

  const quickActions = [
    { label: "Solve Maths", icon: Calculator, query: "मुझे गणित का एक सवाल हल करना है। कृपया स्टेप-बाय-स्टेप समझाएं।" },
    { label: "Ask Science", icon: Microscope, query: "मुझे विज्ञान का एक कॉन्सेप्ट समझना है।" },
    { label: "Exam Answer", icon: Edit3, query: "बोर्ड परीक्षा के लिए एक लॉन्ग आंसर कैसे लिखें? मुझे एक उदाहरण दें।" },
    { label: "VVI Questions", icon: Target, query: "कृपया मुझे बोर्ड परीक्षा के लिए VVI (Very Very Important) प्रश्न बताएं।" },
    { label: "Explain Chapter", icon: BookOpen, query: "मुझे एक चैप्टर को संक्षेप में समझाएं।" },
    { label: "Revision", icon: RefreshCw, query: "मुझे बोर्ड परीक्षा के लिए रिवीजन टिप्स दें।" },
    { label: "Clear My Doubt", icon: HelpCircle, query: "मेरा एक डाउट है, कृपया इसे स्पष्ट करें।" },
  ];

  if (!user) {
    return (
      <div className="flex-1 bg-slate-50 flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="text-center">
          <Brain className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-700">Please Login</h2>
          <p className="text-slate-500">You need to be logged in to use the AI Tutor.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-slate-50 p-4 md:p-6 flex gap-6 h-[calc(100vh-4rem)] relative z-10 overflow-hidden">
      
      {/* Sidebar - Chat History */}
      <div className="hidden lg:flex flex-col w-72 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-800">Chat History</h3>
          <Button size="icon" variant="ghost" onClick={startNewConversation} title="New Chat">
            <Plus className="w-5 h-5 text-blue-600" />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {fetchingHistory ? (
            <div className="flex justify-center p-4"><Loader2 className="w-6 h-6 animate-spin text-slate-400" /></div>
          ) : conversations.length === 0 ? (
            <div className="text-center p-4 text-sm text-slate-500">No previous chats.</div>
          ) : (
            conversations.map(conv => (
              <div 
                key={conv.id} 
                className={cn(
                  "flex items-center justify-between p-3 rounded-xl cursor-pointer group transition-colors",
                  currentConversationId === conv.id ? "bg-blue-50" : "hover:bg-slate-50"
                )}
                onClick={() => selectConversation(conv.id)}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <FileText className={cn("w-4 h-4 shrink-0", currentConversationId === conv.id ? "text-blue-600" : "text-slate-400")} />
                  <span className={cn(
                    "text-sm truncate",
                    currentConversationId === conv.id ? "font-semibold text-blue-700" : "text-slate-600"
                  )}>
                    {conv.title}
                  </span>
                </div>
                <button 
                  className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-opacity"
                  onClick={(e) => { e.stopPropagation(); handleDeleteConversation(conv.id); }}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <Card className="flex-1 flex flex-col h-full shadow-md rounded-3xl overflow-hidden border-slate-200">
        <CardHeader className="border-b border-slate-100 bg-white z-10 flex flex-row items-center justify-between gap-4 py-4 px-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center shadow-inner">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-xl font-black text-slate-900 tracking-tight">BIHAR BOARD AI TUTOR</CardTitle>
              <CardDescription className="text-slate-500 font-medium">कक्षा 9वीं से 12वीं तक आपकी पढ़ाई का स्मार्ट साथी</CardDescription>
            </div>
          </div>
          <Button variant="outline" size="sm" className="lg:hidden" onClick={startNewConversation}>
            <Plus className="w-4 h-4 mr-1" /> New
          </Button>
        </CardHeader>
        
        <CardContent className="flex-1 overflow-y-auto p-0 bg-slate-50/50 flex flex-col">
          {/* Quick Actions (only show if it's a new empty chat) */}
          {messages.length === 1 && currentConversationId === null && (
             <div className="p-6 md:p-8">
               <p className="text-sm font-semibold text-slate-500 mb-4 tracking-wider uppercase">Quick Actions</p>
               <div className="flex flex-wrap gap-2">
                  {quickActions.map((action, i) => (
                    <button 
                      key={i} 
                      onClick={() => handleQuickAction(action.query)}
                      className="flex items-center gap-2 bg-white border border-slate-200 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700 text-slate-600 text-sm font-medium py-2 px-4 rounded-full transition-all shadow-sm"
                    >
                      <action.icon className="w-4 h-4" />
                      {action.label}
                    </button>
                  ))}
               </div>
             </div>
          )}

          <div className="flex-1 p-4 md:p-6 space-y-6">
            {messages.map((msg, idx) => (
              <div key={idx} className={cn("flex w-full", msg.role === 'user' ? "justify-end" : "justify-start")}>
                {msg.role === 'model' && (
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3 shrink-0 mt-1">
                    <Brain className="w-4 h-4 text-blue-600" />
                  </div>
                )}
                <div className={cn(
                  "max-w-[85%] rounded-3xl p-5 text-sm md:text-base leading-relaxed",
                  msg.role === 'user' 
                    ? "bg-slate-900 text-white rounded-br-sm shadow-md" 
                    : "bg-white border border-slate-200 text-slate-800 rounded-bl-sm shadow-sm prose prose-sm md:prose-base prose-slate max-w-none"
                )}>
                  {msg.role === 'model' ? (
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {msg.content}
                    </ReactMarkdown>
                  ) : (
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                  )}
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="flex justify-start items-center">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3 shrink-0">
                  <Brain className="w-4 h-4 text-blue-600" />
                </div>
                <div className="bg-white border border-slate-200 rounded-3xl rounded-bl-sm p-5 shadow-sm flex items-center gap-2 h-[52px]">
                  <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </CardContent>

        <div className="p-4 bg-white border-t border-slate-100 relative">
          
          {/* Image Preview */}
          {selectedImage && (
            <div className="absolute bottom-full left-6 mb-2 bg-white p-2 rounded-xl border border-slate-200 shadow-lg flex items-start gap-2">
              <img src={selectedImage} alt="Upload preview" className="h-20 w-auto rounded-lg object-cover" />
              <button onClick={clearImage} className="p-1 bg-slate-100 hover:bg-slate-200 rounded-full text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="flex items-end gap-2 max-w-4xl mx-auto bg-slate-50 border border-slate-300 rounded-3xl pl-4 pr-2 py-2 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent transition-all shadow-sm">
            <textarea 
               placeholder="Ask a doubt... (Photo से सवाल पूछें)" 
               className="flex-1 bg-transparent border-none focus:outline-none text-slate-800 min-h-[44px] max-h-32 py-3 resize-none"
               value={query}
               onChange={(e) => {
                 setQuery(e.target.value);
                 e.target.style.height = 'auto';
                 e.target.style.height = e.target.scrollHeight + 'px';
               }}
               onKeyDown={(e) => {
                 if (e.key === 'Enter' && !e.shiftKey) {
                   e.preventDefault();
                   handleSend();
                 }
               }}
               rows={1}
            />
            
            <div className="flex items-center gap-1 mb-1">
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
              />
              <Button size="icon" variant="ghost" className="h-10 w-10 text-slate-500 hover:bg-slate-200 hover:text-blue-700 rounded-full transition-colors" onClick={() => fileInputRef.current?.click()}>
                <ImageIcon className="w-5 h-5" />
              </Button>
              <Button 
                size="icon" 
                className={cn(
                  "h-10 w-10 rounded-full shadow-md transition-all",
                  (query.trim() || selectedImage) && !loading ? "bg-slate-900 hover:bg-slate-800 text-white" : "bg-slate-300 text-slate-500"
                )} 
                onClick={() => handleSend()} 
                disabled={loading || (!query.trim() && !selectedImage)}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="text-center mt-3">
            <span className="text-[11px] text-slate-400 font-medium">BIHAR BOARD AI Tutor is an independent educational tool. Always verify important official information.</span>
          </div>
        </div>
      </Card>
    </div>
  );
};
`;

fs.writeFileSync('src/pages/student/AiTutorPage.tsx', code);
