const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const storeImportTarget = `import { CoursesPage } from "./pages/public/CoursesPage";`;
const storeImportReplacement = `import { CoursesPage } from "./pages/public/CoursesPage";
import { StorePage } from "./pages/public/StorePage";
import { AdminOrdersPage } from "./pages/admin/AdminOrdersPage";`;

code = code.replace(storeImportTarget, storeImportReplacement);

const storeRouteTarget = `        <Route path="/courses" element={<CoursesPage />} />`;
const storeRouteReplacement = `        <Route path="/courses" element={<CoursesPage />} />
        <Route path="/store" element={<StorePage />} />
        <Route path="/admin/orders" element={<AdminOrdersPage />} />`;

code = code.replace(storeRouteTarget, storeRouteReplacement);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx");
