const fs = require('fs');
let code = fs.readFileSync('src/context/AuthContext.tsx', 'utf-8');

const target = `  const fetchOrCreateProfile = async (
    currentUser: User, 
    role: 'student' | 'parent' | 'teacher' = 'student',
    customName?: string,
    customProvider?: string
  ) => {
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        setProfile(userSnap.data() as UserProfile);
      } else {
        const newProfile: Partial<UserProfile> = {
          uid: currentUser.uid,
          name: customName || currentUser.displayName || '',
          email: currentUser.email || '',
          photoURL: currentUser.photoURL || '',
          authProvider: customProvider || (currentUser.providerData[0]?.providerId === 'password' ? 'password' : 'google'),
          role: role,
          accountStatus: 'active'
        };
        
        await setDoc(userRef, {
          ...newProfile,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        
        const freshSnap = await getDoc(userRef);
        setProfile(freshSnap.data() as UserProfile);
      }
    } catch (e) {
      console.error("Error fetching/creating profile:", e);
    }
  };`;

const replacement = `  const fetchOrCreateProfile = async (
    currentUser: User, 
    role: 'student' | 'parent' | 'teacher' = 'student',
    customName?: string,
    customProvider?: string
  ) => {
    try {
      const token = await currentUser.getIdToken();
      const response = await fetch('/api/auth/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': \`Bearer \${token}\`
        },
        body: JSON.stringify({ role, customName, customProvider })
      });
      
      if (!response.ok) {
         throw new Error(\`Sync failed with status \${response.status}\`);
      }
      const data = await response.json();
      setProfile(data.user as UserProfile);
    } catch (e) {
      console.error("Error fetching/creating profile:", e);
    }
  };`;

if (code.includes(target)) {
  fs.writeFileSync('src/context/AuthContext.tsx', code.replace(target, replacement));
  console.log("Patched fetchOrCreateProfile");
} else {
  console.log("Could not find target");
}

const target2 = `  const deleteUserAccount = async (): Promise<SignInResult> => {
    if (!auth.currentUser) return { success: false, error: 'No user signed in' };
    try {
      const uid = auth.currentUser.uid;
      try {
        await deleteDoc(doc(db, 'users', uid));
      } catch(e) {
        console.warn("Could not delete user document, might require admin privileges.");
      }
      await deleteUser(auth.currentUser);
      setProfile(null);
      setUser(null);
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to delete account. You may need to log in again recently to perform this action.' };
    }
  };`;

const replacement2 = `  const deleteUserAccount = async (): Promise<SignInResult> => {
    if (!auth.currentUser) return { success: false, error: 'No user signed in' };
    try {
      const uid = auth.currentUser.uid;
      // We rely on backend or auth to handle deletion, just delete auth user.
      await deleteUser(auth.currentUser);
      setProfile(null);
      setUser(null);
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message || 'Failed to delete account. You may need to log in again recently to perform this action.' };
    }
  };`;

if (code.includes(target2)) {
  fs.writeFileSync('src/context/AuthContext.tsx', fs.readFileSync('src/context/AuthContext.tsx', 'utf-8').replace(target2, replacement2));
  console.log("Patched deleteUserAccount");
} else {
  console.log("Could not find target2");
}

