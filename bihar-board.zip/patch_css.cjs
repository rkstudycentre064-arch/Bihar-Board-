const fs = require('fs');

let code = fs.readFileSync('src/index.css', 'utf8');

const bgStyles = `
/* Background Design System */
.page-background {
  @apply bg-[#FDFDFD] min-h-screen relative overflow-hidden;
}

.hero-background {
  background: linear-gradient(135deg, #F0F7FF 0%, #FFFFFF 100%);
  position: relative;
}

/* Subtle dot grid pattern */
.hero-background::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image: radial-gradient(circle at 2px 2px, rgba(37, 99, 235, 0.08) 1px, transparent 0);
  background-size: 32px 32px;
  z-index: 0;
  pointer-events: none;
}

/* Subtle decorative blobs */
.decorative-shape {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  z-index: 0;
  pointer-events: none;
}

.shape-1 {
  top: -10%;
  left: -5%;
  width: 45vw;
  height: 45vw;
  background: rgba(147, 197, 253, 0.25); /* blue-300 with low opacity */
}

.shape-2 {
  bottom: -20%;
  right: -10%;
  width: 40vw;
  height: 40vw;
  background: rgba(253, 224, 71, 0.12); /* yellow-300 with low opacity */
}

.shape-3 {
  top: 30%;
  right: 15%;
  width: 25vw;
  height: 25vw;
  background: rgba(96, 165, 250, 0.15); /* blue-400 with low opacity */
}

.section-light {
  @apply bg-white relative z-10;
}

.section-blue {
  @apply bg-[#F4F9FF] relative z-10;
}

.section-navy {
  @apply bg-slate-900 relative z-10 overflow-hidden;
}

/* Very faint education/geometric pattern */
.education-pattern {
  position: absolute;
  inset: 0;
  opacity: 0.2;
  pointer-events: none;
  background-image: url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 3.33333L0 13.3333L20 23.3333L40 13.3333L20 3.33333ZM20 28.3333L5.83333 21.25L0 24.1667L20 34.1667L40 24.1667L34.1667 21.25L20 28.3333Z' fill='%232563EB' fill-opacity='0.03' fill-rule='evenodd'/%3E%3C/svg%3E");
  z-index: 0;
}

/* Animations that respect user preferences */
@media (prefers-reduced-motion: no-preference) {
  .animate-float {
    animation: float 20s ease-in-out infinite;
  }
  .animate-float-delayed {
    animation: float 22s ease-in-out infinite;
    animation-delay: -7s;
  }
  .animate-float-slow {
    animation: float 25s ease-in-out infinite;
    animation-delay: -2s;
  }
}

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(2% , -4%) scale(1.05); }
  66% { transform: translate(-2%, 3%) scale(0.95); }
}
`;

fs.writeFileSync('src/index.css', code + '\n' + bgStyles);
