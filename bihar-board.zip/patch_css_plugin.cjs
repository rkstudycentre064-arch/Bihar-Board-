const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');
if (!css.includes('@plugin "@tailwindcss/typography"')) {
  css = '@import "tailwindcss";\n@plugin "@tailwindcss/typography";' + css.replace('@import "tailwindcss";', '');
  fs.writeFileSync('src/index.css', css);
}
