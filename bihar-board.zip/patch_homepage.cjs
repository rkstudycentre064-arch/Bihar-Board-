const fs = require('fs');

let code = fs.readFileSync('src/pages/HomePage.tsx', 'utf8');

// Add imports
code = code.replace(
  "import { Button } from '../components/ui/Button';",
  "import { Button } from '../components/ui/Button';\nimport { WebsiteRatingForm } from '../components/ui/WebsiteRatingForm';\nimport { WebsiteRatingSummary } from '../components/ui/WebsiteRatingSummary';"
);

// Add the section before the CTA
const ctaTarget = `      {/* CTA Section */}`;
const ratingSection = `      {/* Website Rating Section */}
      <section className="py-24 bg-slate-50 border-t border-slate-100">
        <div className="container mx-auto px-4 max-w-6xl space-y-16">
          <WebsiteRatingSummary />
          <WebsiteRatingForm />
        </div>
      </section>

      {/* CTA Section */}`;

code = code.replace(ctaTarget, ratingSection);

fs.writeFileSync('src/pages/HomePage.tsx', code);
