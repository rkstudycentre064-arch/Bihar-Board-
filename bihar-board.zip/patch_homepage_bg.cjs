const fs = require('fs');

let code = fs.readFileSync('src/pages/HomePage.tsx', 'utf8');

// 1. Replace main wrapper
code = code.replace(
  '<div className="flex flex-col bg-[#FDFDFD]">',
  '<div className="flex flex-col page-background">'
);

// 2. Replace Hero Section background
code = code.replace(
  '<section className="relative overflow-hidden pt-32 pb-24 lg:pt-40 lg:pb-32">',
  '<section className="hero-background pt-32 pb-24 lg:pt-40 lg:pb-32">'
);
code = code.replace(
  '<div className="absolute inset-0 bg-slate-50/50 z-0 pointer-events-none"></div>',
  `<div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="decorative-shape shape-1 animate-float"></div>
          <div className="decorative-shape shape-2 animate-float-delayed"></div>
          <div className="decorative-shape shape-3 animate-float-slow"></div>
        </div>`
);

// 3. Replace Features Grid background
code = code.replace(
  '<section className="py-24 bg-white border-t border-slate-100">',
  '<section className="py-24 section-light border-t border-slate-100">\n        <div className="education-pattern"></div>'
);

// 4. Replace Rating Section background
code = code.replace(
  '<section className="py-24 bg-slate-50 border-t border-slate-100">',
  '<section className="py-24 section-blue border-t border-slate-100">'
);

// 5. Replace CTA Section background
code = code.replace(
  '<section className="py-24 bg-slate-900 text-white">',
  `<section className="py-24 section-navy text-white">
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-20">
          <div className="decorative-shape shape-1 animate-float"></div>
          <div className="decorative-shape shape-2 animate-float-delayed"></div>
        </div>
        <div className="education-pattern opacity-10"></div>`
);

// Update some elements in the features grid for better shadow/border according to "Card background" instructions.
// The cards are: <div className={`w-14 h-14 rounded-2xl ${feature.bg} flex items-center justify-center mb-6`}>...
// But the wrapper is: <div key={i} className="group flex flex-col items-start">
code = code.replace(
  '<div key={i} className="group flex flex-col items-start">',
  '<div key={i} className="group flex flex-col items-start bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow relative z-10">'
);

fs.writeFileSync('src/pages/HomePage.tsx', code);
