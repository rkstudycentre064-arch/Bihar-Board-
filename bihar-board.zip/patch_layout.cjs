const fs = require('fs');
let code = fs.readFileSync('src/components/layout/WebsiteLayout.tsx', 'utf-8');

const target = `<Link to="/dashboard">
                  <Button variant="outline" className="gap-2">
                    <UserCircle2 className="w-4 h-4" />
                    Dashboard
                  </Button>
                </Link>`;
                
const replacement = `<Link to="/dashboard">
                  <Button variant="outline" className="gap-2">
                    <UserCircle2 className="w-4 h-4" />
                    Dashboard
                  </Button>
                </Link>
                {profile?.role === 'admin' && (
                  <Link to="/admin/orders">
                    <Button variant="outline" className="gap-2 bg-slate-900 text-white hover:bg-slate-800">
                      Orders Admin
                    </Button>
                  </Link>
                )}`;

if (code.includes(target)) {
  fs.writeFileSync('src/components/layout/WebsiteLayout.tsx', code.replace(target, replacement));
  console.log("Patched WebsiteLayout");
} else {
  console.log("Target not found in WebsiteLayout");
}
