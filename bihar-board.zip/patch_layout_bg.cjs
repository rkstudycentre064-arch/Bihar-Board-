const fs = require('fs');

let code = fs.readFileSync('src/components/layout/WebsiteLayout.tsx', 'utf8');

code = code.replace(
  '<div className="flex flex-col min-h-screen font-sans bg-slate-50">',
  '<div className="flex flex-col min-h-screen font-sans page-background">'
);

fs.writeFileSync('src/components/layout/WebsiteLayout.tsx', code);
