const fs = require('fs');
let code = fs.readFileSync('src/pages/public/StudyMaterialsPage.tsx', 'utf-8');

// Remove firestore imports
code = code.replace("import { collection, query, getDocs, addDoc, serverTimestamp, orderBy } from 'firebase/firestore';", "");
code = code.replace("import { db } from '../../lib/firebase';", "");

const targetFetch = `  const fetchMaterials = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, 'materials'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const fetched: Material[] = [];
      querySnapshot.forEach((doc) => {
        fetched.push({ id: doc.id, ...doc.data() } as Material);
      });
      setMaterials(fetched);
    } catch (error) {
      console.error("Error fetching materials:", error);
    } finally {
      setLoading(false);
    }
  };`;

const mockFetch = `  const fetchMaterials = async () => {
    setLoading(true);
    try {
      // Mock data since backend is currently migrating
      const fetched: Material[] = [
        { id: '1', title: 'Class 10 Math Formula Sheet', category: 'Notes', className: 'Class 10', subject: 'Math', language: 'Hindi', format: 'PDF', pages: 5, url: '#' },
        { id: '2', title: 'Class 12 Physics VVI', category: 'Important Questions', className: 'Class 12', subject: 'Physics', language: 'English', format: 'PDF', pages: 12, url: '#' }
      ];
      setMaterials(fetched);
    } catch (error) {
      console.error("Error fetching materials:", error);
    } finally {
      setLoading(false);
    }
  };`;

code = code.replace(targetFetch, mockFetch);

const targetAdd = `  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'materials'), {
        ...newMaterial,
        pages: Number(newMaterial.pages),
        createdAt: serverTimestamp(),
        createdBy: profile?.uid,
        uploaderName: profile?.name
      });
      setShowAddModal(false);
      fetchMaterials();
    } catch (error) {
      console.error("Error adding material:", error);
      alert("Failed to add material");
    } finally {
      setIsSubmitting(false);
    }
  };`;

const mockAdd = `  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      // Mock add
      setShowAddModal(false);
      fetchMaterials();
    } catch (error) {
      console.error("Error adding material:", error);
      alert("Failed to add material");
    } finally {
      setIsSubmitting(false);
    }
  };`;

code = code.replace(targetAdd, mockAdd);

fs.writeFileSync('src/pages/public/StudyMaterialsPage.tsx', code);
console.log("Patched StudyMaterialsPage");
