const fs = require('fs');
let code = fs.readFileSync('src/pages/admin/AdminOrdersPage.tsx', 'utf-8');
code = code.replace("const token = await window.requireAuthToken?.() || ''; // Not sure how they get token, let's use standard Firebase auth", 
"// fetch token via firebase auth");
fs.writeFileSync('src/pages/admin/AdminOrdersPage.tsx', code);
