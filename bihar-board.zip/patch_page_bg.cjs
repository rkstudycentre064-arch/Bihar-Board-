const fs = require('fs');

let code = fs.readFileSync('src/index.css', 'utf8');

// Update .page-background to have pseudo-elements for the subtle shapes so all pages get them automatically!
const target = `.page-background {
  @apply bg-[#FDFDFD] min-h-screen relative overflow-hidden;
}`;

const replacement = `.page-background {
  @apply bg-[#f4f9ff] min-h-screen relative overflow-hidden;
}

.page-background::before {
  content: '';
  position: fixed;
  top: -10%;
  left: -5%;
  width: 50vw;
  height: 50vw;
  background: rgba(147, 197, 253, 0.15); /* very soft blue blob */
  filter: blur(100px);
  border-radius: 50%;
  z-index: 0;
  pointer-events: none;
}

.page-background::after {
  content: '';
  position: fixed;
  bottom: -10%;
  right: -5%;
  width: 40vw;
  height: 40vw;
  background: rgba(253, 224, 71, 0.08); /* very soft yellow blob */
  filter: blur(100px);
  border-radius: 50%;
  z-index: 0;
  pointer-events: none;
}`;

code = code.replace(target, replacement);

fs.writeFileSync('src/index.css', code);
