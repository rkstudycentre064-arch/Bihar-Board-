const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const targetImport = `import { AdminTestsPage } from "./pages/admin/AdminTestsPage";`;
const replacementImport = `import { AdminTestsPage } from "./pages/admin/AdminTestsPage";
import { AdminQuestionsPage } from "./pages/admin/AdminQuestionsPage";`;

code = code.replace(targetImport, replacementImport);

const targetRoute = `<Route path="/admin/cms/tests" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminTestsPage /></ProtectedRoute>} />`;
const replacementRoute = `<Route path="/admin/cms/tests" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminTestsPage /></ProtectedRoute>} />
        <Route path="/admin/cms/questions" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminQuestionsPage /></ProtectedRoute>} />`;

code = code.replace(targetRoute, replacementRoute);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx for questions");
