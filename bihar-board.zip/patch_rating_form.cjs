const fs = require('fs');
let code = fs.readFileSync('src/components/ui/WebsiteRatingForm.tsx', 'utf8');

code = code.replace(
  'className="bg-slate-900 rounded-3xl p-8 text-center text-white"',
  'className="bg-white rounded-3xl p-8 text-center text-slate-900 border border-slate-100 shadow-sm"'
);

code = code.replace(
  'className="text-slate-300 mb-6 max-w-md mx-auto"',
  'className="text-slate-500 mb-6 max-w-md mx-auto"'
);

code = code.replace(
  'bg-slate-800 border-slate-700 hover:bg-slate-700 text-white',
  'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
);

fs.writeFileSync('src/components/ui/WebsiteRatingForm.tsx', code);
