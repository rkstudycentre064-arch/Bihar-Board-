const fs = require('fs');
let code = fs.readFileSync('src/components/ui/WebsiteRatingSummary.tsx', 'utf8');

code = code.replace(
  'className="bg-slate-900 rounded-3xl p-8 lg:p-12 text-white shadow-xl"',
  'className="bg-white rounded-3xl p-8 lg:p-12 text-slate-900 border border-slate-100 shadow-sm"'
);

code = code.replace(
  'className="text-3xl font-black text-white mb-2"',
  'className="text-3xl font-black text-slate-900 mb-2"'
);

code = code.replace(
  'className="text-slate-400 mb-6"',
  'className="text-slate-500 mb-6"'
);

// Star fill changes inside
code = code.replace(
  /fill-slate-700 text-slate-700/g,
  'fill-slate-200 text-slate-200'
);

code = code.replace(
  /text-slate-400/g,
  'text-slate-500'
);

code = code.replace(
  'bg-slate-800 rounded-full',
  'bg-slate-100 rounded-full'
);

code = code.replace(
  'bg-slate-800/50 rounded-2xl p-6 border border-slate-700',
  'bg-white rounded-2xl p-6 border border-slate-100 shadow-sm'
);

code = code.replace(
  'text-slate-200 mb-4 text-sm',
  'text-slate-700 mb-4 text-sm'
);

code = code.replace(
  'text-sm font-bold text-slate-200',
  'text-sm font-bold text-slate-900'
);

code = code.replace(
  'text-slate-300',
  'text-slate-700'
);

fs.writeFileSync('src/components/ui/WebsiteRatingSummary.tsx', code);
