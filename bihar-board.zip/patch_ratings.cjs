const fs = require('fs');

let form = fs.readFileSync('src/components/ui/WebsiteRatingForm.tsx', 'utf8');
form = form.replace(
  'console.error("Error loading rating:", err);',
  `if (err.message && err.message.includes('offline')) {
        console.warn("Client offline, skipping rating load.");
      } else {
        console.error("Error loading rating:", err);
      }`
);
fs.writeFileSync('src/components/ui/WebsiteRatingForm.tsx', form);

let summary = fs.readFileSync('src/components/ui/WebsiteRatingSummary.tsx', 'utf8');
summary = summary.replace(
  "console.error('Error fetching public ratings', err);",
  `if (err.message && err.message.includes('offline')) {
        console.warn("Client offline, skipping public ratings load.");
      } else {
        console.error('Error fetching public ratings', err);
      }`
);
fs.writeFileSync('src/components/ui/WebsiteRatingSummary.tsx', summary);
