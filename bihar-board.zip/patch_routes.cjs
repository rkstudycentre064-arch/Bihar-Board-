const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const targetImport = `import { AdminPanel } from "./pages/admin/AdminPanel";`;
const replacementImport = `import { AdminPanel } from "./pages/admin/AdminPanel";
import { AdminCMSPage } from "./pages/admin/AdminCMSPage";
import { AdminAddContentPage } from "./pages/admin/AdminAddContentPage";
import { ContentDetailPage } from "./pages/public/ContentDetailPage";`;

code = code.replace(targetImport, replacementImport);

const targetRoute = `<Route path="/admin-panel" element={<ProtectedRoute allowedRoles={['admin']}><AdminPanel /></ProtectedRoute>} />`;
const replacementRoute = `<Route path="/admin-panel" element={<ProtectedRoute allowedRoles={['admin']}><AdminPanel /></ProtectedRoute>} />
        <Route path="/admin/cms" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminCMSPage /></ProtectedRoute>} />
        <Route path="/admin/cms/add" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminAddContentPage /></ProtectedRoute>} />
        <Route path="/content/:id" element={<ContentDetailPage />} />`;

code = code.replace(targetRoute, replacementRoute);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx");
