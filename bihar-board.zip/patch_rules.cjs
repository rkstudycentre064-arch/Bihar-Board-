const fs = require('fs');

let rules = fs.readFileSync('firestore.rules', 'utf8');

const aiRules = `
    // AI Conversations
    match /aiConversations/{conversationId} {
      allow read: if isSignedIn() && isOwner(resource.data.userId);
      allow create: if isSignedIn() && isOwner(incoming().userId);
      allow update: if isSignedIn() && isOwner(existing().userId) && isOwner(incoming().userId);
      allow delete: if isSignedIn() && isOwner(resource.data.userId);
    }
    
    match /aiMessages/{messageId} {
      allow read: if isSignedIn() && isOwner(resource.data.userId);
      allow create: if isSignedIn() && isOwner(incoming().userId);
      allow update: if isSignedIn() && isOwner(existing().userId) && isOwner(incoming().userId);
      allow delete: if isSignedIn() && isOwner(resource.data.userId);
    }
    
    // Admins Collection`;

rules = rules.replace('    // Admins Collection', aiRules);

fs.writeFileSync('firestore.rules', rules);
