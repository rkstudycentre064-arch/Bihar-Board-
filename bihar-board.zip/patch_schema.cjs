const fs = require('fs');
let code = fs.readFileSync('src/db/schema.ts', 'utf-8');

const newTables = `
// Access Control
export const purchases = pgTable('purchases', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  orderId: integer('order_id').references(() => orders.id).notNull(),
  productId: integer('product_id').references(() => products.id).notNull(),
  paymentId: integer('payment_id').references(() => payments.id),
  paymentStatus: text('payment_status').notNull().default('PENDING'),
  accessStatus: text('access_status').notNull().default('REVOKED'), // GRANTED, REVOKED
  grantedAt: timestamp('granted_at'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const paymentAuditLogs = pgTable('payment_audit_logs', {
  id: serial('id').primaryKey(),
  eventId: text('event_id').notNull().unique(), // idempotency key
  provider: text('provider').notNull(),
  orderId: integer('order_id'),
  paymentId: integer('payment_id'),
  eventType: text('event_type').notNull(),
  verificationStatus: text('verification_status').notNull(), // SUCCESS, FAILED
  processingStatus: text('processing_status').notNull(), // PROCESSED, IGNORED, ERROR
  timestamp: timestamp('timestamp').defaultNow(),
});
`;

code = code + newTables;

code = code.replace(
  "totalAmount: decimal('total_amount').notNull(),",
  "totalAmount: decimal('total_amount').notNull(),\n  currency: text('currency').default('INR'),\n  providerOrderId: text('provider_order_id'),"
);

fs.writeFileSync('src/db/schema.ts', code);
console.log("Patched schema");
