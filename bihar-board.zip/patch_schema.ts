import fs from 'fs';
let content = fs.readFileSync('src/db/schema.ts', 'utf8');
if (!content.includes('export const payments = pgTable')) {
  content += `

// Payments
export const payments = pgTable('payments', {
  id: serial('id').primaryKey(),
  paymentId: text('payment_id').notNull().unique(), // Our internal unique payment reference
  orderId: integer('order_id').references(() => orders.id).notNull(),
  userId: integer('user_id').references(() => users.id).notNull(),
  provider: text('provider').notNull().default('[UPI PAYMENT PROVIDER]'),
  providerPaymentId: text('provider_payment_id'),
  providerOrderId: text('provider_order_id'),
  method: text('method').notNull().default('UPI'), // UPI_INTENT, UPI_QR, UPI_COLLECT
  amount: decimal('amount').notNull(),
  currency: text('currency').notNull().default('INR'),
  status: text('status').notNull().default('PENDING'), // PENDING, PROCESSING, SUCCESS, FAILED, CANCELLED, EXPIRED, REFUNDED
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
  verifiedAt: timestamp('verified_at'),
});
`;
  fs.writeFileSync('src/db/schema.ts', content);
  console.log('Added payments table');
}
