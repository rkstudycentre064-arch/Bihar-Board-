const fs = require('fs');
let code = fs.readFileSync('src/db/schema.ts', 'utf-8');

const newTables = `
// CMS Additions
export const contentVersions = pgTable('content_versions', {
  id: serial('id').primaryKey(),
  contentId: integer('content_id').references(() => contents.id).notNull(),
  version: integer('version').notNull(),
  data: json('data').notNull(), // Snapshot of content
  updatedBy: integer('updated_by').references(() => users.id),
  changeSummary: text('change_summary'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const bookmarks = pgTable('bookmarks', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  contentId: integer('content_id').references(() => contents.id).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const progress = pgTable('progress', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  contentId: integer('content_id').references(() => contents.id),
  courseId: integer('course_id'),
  progressPercentage: integer('progress_percentage').default(0),
  status: text('status').default('started'), // started, completed
  lastAccessed: timestamp('last_accessed').defaultNow(),
});

export const reviews = pgTable('reviews', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  contentId: integer('content_id').references(() => contents.id).notNull(),
  rating: integer('rating').notNull(),
  reviewText: text('review_text'),
  status: text('status').default('pending'), // pending, approved, rejected
  createdAt: timestamp('created_at').defaultNow(),
});

export const contentReports = pgTable('content_reports', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  contentId: integer('content_id').references(() => contents.id).notNull(),
  reason: text('reason').notNull(),
  description: text('description'),
  status: text('status').default('open'), // open, resolved, dismissed
  createdAt: timestamp('created_at').defaultNow(),
});

export const contentAccess = pgTable('content_access', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  productId: integer('product_id').references(() => products.id),
  contentId: integer('content_id').references(() => contents.id).notNull(),
  orderId: integer('order_id').references(() => orders.id),
  purchaseId: integer('purchase_id').references(() => purchases.id),
  status: text('status').default('ACTIVE'), // ACTIVE, EXPIRED, REVOKED
  grantedAt: timestamp('granted_at').defaultNow(),
  expiresAt: timestamp('expires_at'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const adminAuditLogs = pgTable('admin_audit_logs', {
  id: serial('id').primaryKey(),
  adminId: integer('admin_id').references(() => users.id).notNull(),
  action: text('action').notNull(),
  resourceType: text('resource_type').notNull(),
  resourceId: text('resource_id'),
  metadata: json('metadata'),
  timestamp: timestamp('timestamp').defaultNow(),
});
`;

code = code.replace("export const faqCategories", newTables + "\nexport const faqCategories");

// Update contents table
const oldContents = `export const contents = pgTable('contents', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  topicId: integer('topic_id').references(() => topics.id).notNull(),
  type: text('type').notNull(), // video, pdf, note
  isPremium: boolean('is_premium').default(false),
  status: text('status').default('published'), // draft, review, published
});`;

const newContents = `export const contents = pgTable('contents', {
  id: serial('id').primaryKey(),
  title: text('title').notNull(),
  shortDescription: text('short_description'),
  fullDescription: text('full_description'),
  topicId: integer('topic_id').references(() => topics.id),
  classId: integer('class_id').references(() => classes.id),
  subjectId: integer('subject_id').references(() => subjects.id),
  type: text('type').notNull(), // video, pdf, note, mcq
  difficulty: text('difficulty'),
  tags: text('tags'),
  thumbnail: text('thumbnail'),
  authorId: integer('author_id').references(() => users.id),
  
  // Pricing & Access
  isPremium: boolean('is_premium').default(false),
  originalPrice: decimal('original_price'),
  salePrice: decimal('sale_price'),
  discount: decimal('discount'),
  previewPercentage: integer('preview_percentage'),
  previewPages: integer('preview_pages'),
  previewDuration: integer('preview_duration'),
  
  // Status
  status: text('status').default('DRAFT'), // DRAFT, PENDING_REVIEW, APPROVED, PUBLISHED, SCHEDULED, UNPUBLISHED, REJECTED, ARCHIVED
  
  // File References
  fileUrl: text('file_url'),
  
  // SEO
  seoTitle: text('seo_title'),
  metaDescription: text('meta_description'),
  slug: text('slug'),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});`;

code = code.replace(oldContents, newContents);

fs.writeFileSync('src/db/schema.ts', code);
console.log("Patched schema");
