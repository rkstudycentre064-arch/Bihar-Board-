const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');

// The AI prompt
const aiRoute = `
  // AI Tutor Route
  app.post("/api/ai/chat", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { history = [], message, imageBase64 } = req.body;
      
      const { GoogleGenAI } = await import('@google/genai');
      
      const apiKey = process.env.AI_API_KEY || process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "AI API Key not configured." });
      }
      
      const ai = new GoogleGenAI({ apiKey });
      const model = process.env.AI_MODEL || 'gemini-2.5-flash';

      const systemInstruction = \`
You are "BIHAR BOARD AI TUTOR", an educational assistant for students from Class 9 to Class 12.
MAIN GOAL: Provide fast, accurate, clear, student-friendly and exam-oriented answers to education-related questions.

RULES:
1. CLASS SUPPORT: Support Class 9 to 12.
2. SUBJECTS: Math, Science, Social Science, Hindi, English, etc.
3. BE FAST: Start with the answer directly. No long intros.
4. LANGUAGE: Answer in the same language as the user (Hindi, English, or Hinglish). Keep it simple.
5. MATH SOLUTION FORMAT: 
   दिया है: ...
   सूत्र: ...
   हल: ...
   अतः उत्तर: ...
6. EXAM ORIENTED: For subjective questions, use clear headings and bullet points. Use "Answer:" and "Key Points:".
7. ACCURACY: Do not hallucinate facts. If unsure, say: "इस प्रश्न का सही उत्तर सुनिश्चित करने के लिए मुझे उपलब्ध स्रोत/पुस्तक की जानकारी चाहिए।"
8. UNDERSTANDING: Focus on Explanation + Understanding (Why, How, Examples).
9. BRANDING: You are BIHAR BOARD AI TUTOR, an independent educational platform. NOT affiliated with government.
10. TONE: Friendly, respectful, patient. Correct mistakes politely.
\`;

      let contents = [];
      
      // Map frontend history to Gemini API format
      for (const msg of history) {
        contents.push({
          role: msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user',
          parts: [{ text: msg.content || '' }]
        });
      }

      const parts = [];
      if (message) {
        parts.push({ text: message });
      }
      
      if (imageBase64) {
        // Strip data:image/png;base64,
        const b64Data = imageBase64.replace(/^data:image\\/\\w+;base64,/, '');
        // Determine mime type from string
        const mimeTypeMatch = imageBase64.match(/^data:(image\\/\\w+);base64,/);
        const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/jpeg';
        parts.push({
          inlineData: {
            data: b64Data,
            mimeType: mimeType
          }
        });
      }

      contents.push({ role: 'user', parts });

      const response = await ai.models.generateContent({
        model: model,
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.5,
        }
      });

      res.json({ text: response.text });
    } catch (error) {
      console.error("AI Error:", error);
      res.status(500).json({ error: "Failed to generate AI response." });
    }
  });
`;

serverCode = serverCode.replace(
  '// Vite middleware for development',
  aiRoute + '\n  // Vite middleware for development'
);

fs.writeFileSync('server.ts', serverCode);
