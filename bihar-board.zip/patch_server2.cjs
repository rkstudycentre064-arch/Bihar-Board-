const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `  // --- API ROUTES ---

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });`;

const replacement = `  // --- API ROUTES ---

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  const { paymentRouter } = await import('./src/api/payment.ts');
  app.use('/api/payment', paymentRouter);
`;

if (code.includes(target)) {
  fs.writeFileSync('server.ts', code.replace(target, replacement));
  console.log("Patched server.ts with paymentRouter");
} else {
  console.log("Target not found in server.ts");
}
