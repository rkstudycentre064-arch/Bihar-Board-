const fs = require('fs');

let code = fs.readFileSync('server.ts', 'utf8');

// Find the auth/sync endpoint and add firestore admin sync
const target = `await db.update(users).set(updateData).where(eq(users.uid, uid));
        dbUser = { ...dbUser, ...updateData };`;
        
const replacement = `await db.update(users).set(updateData).where(eq(users.uid, uid));
        dbUser = { ...dbUser, ...updateData };
        
        if (dbUser.role === 'admin') {
          const { getFirestore } = require('firebase-admin/firestore');
          const firestoreDb = getFirestore();
          await firestoreDb.collection('admins').doc(uid).set({ synced: true, role: 'admin' }, { merge: true }).catch(console.error);
        }`;

code = code.replace(target, replacement);

fs.writeFileSync('server.ts', code);
