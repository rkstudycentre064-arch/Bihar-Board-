const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `  // Sync user with DB on login
  app.post("/api/auth/sync", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!req.user) return res.status(401).json({ error: "Unauthorized" });
      const { role, customName, customProvider } = req.body || {};
      const user = await getOrCreateUser(
        req.user.uid,
        req.user.email || "",
        customName || req.user.name || "User",
        role
      );
      res.json({ user });
    } catch (error: any) {
      console.error("Sync failed:", error);
      res.status(500).json({ error: error.message });
    }
  });`;

const replacement = `  // Sync user with DB on login
  app.post("/api/auth/sync", requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!req.user) return res.status(401).json({ error: "Unauthorized" });
      const { role, customName, customProvider } = req.body || {};
      const user = await getOrCreateUser(
        req.user.uid,
        req.user.email || "",
        customName || req.user.name || "User",
        role
      );
      
      const fullProfile = {
        ...user,
        photoURL: req.user.picture || "",
        authProvider: customProvider || (req.user.firebase?.sign_in_provider || "google"),
        accountStatus: "active",
        updatedAt: user.createdAt
      };
      
      res.json({ user: fullProfile });
    } catch (error: any) {
      console.error("Sync failed:", error);
      res.status(500).json({ error: error.message });
    }
  });`;

if (code.includes(target)) {
  fs.writeFileSync('server.ts', code.replace(target, replacement));
  console.log("Patched server.ts sync with defaults");
} else {
  console.log("Target not found");
}
