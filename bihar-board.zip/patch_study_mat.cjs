const fs = require('fs');
let code = fs.readFileSync('src/pages/public/StudyMaterialsPage.tsx', 'utf-8');

const targetAddDoc = `await addDoc(collection(db, 'materials'), {
        ...newMaterial,
        pages: Number(newMaterial.pages) || 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });`;

const replacementAddDoc = `
      // using backend API instead
      await fetch('/api/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMaterial)
      });
`;

code = code.replace(targetAddDoc, replacementAddDoc);
fs.writeFileSync('src/pages/public/StudyMaterialsPage.tsx', code);
