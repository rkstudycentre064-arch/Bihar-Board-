const fs = require('fs');
let code = fs.readFileSync('src/pages/public/StudyMaterialsPage.tsx', 'utf-8');

// We will replace the entire map function body return statement or the relevant section.
code = code.replace(
  /<a href=\{material\.url\}[^>]*>[\s\S]*?<\/a>/g,
  `<Link to={\`/content/\${material.id || '1'}\`} className="flex-1 md:flex-none"><Button className="w-full gap-2 bg-blue-600 hover:bg-blue-700 text-white" size="sm"><Eye className="w-4 h-4" /> View Details</Button></Link>`
);

fs.writeFileSync('src/pages/public/StudyMaterialsPage.tsx', code);
console.log("Regex replaced.");
