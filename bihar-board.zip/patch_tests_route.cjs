const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const targetImport = `import { AdminCMSPage } from "./pages/admin/AdminCMSPage";`;
const replacementImport = `import { AdminCMSPage } from "./pages/admin/AdminCMSPage";
import { AdminTestsPage } from "./pages/admin/AdminTestsPage";`;

code = code.replace(targetImport, replacementImport);

const targetRoute = `<Route path="/admin/cms/add" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminAddContentPage /></ProtectedRoute>} />`;
const replacementRoute = `<Route path="/admin/cms/add" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminAddContentPage /></ProtectedRoute>} />
        <Route path="/admin/cms/tests" element={<ProtectedRoute allowedRoles={['admin', 'teacher']}><AdminTestsPage /></ProtectedRoute>} />`;

code = code.replace(targetRoute, replacementRoute);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched App.tsx for tests");
