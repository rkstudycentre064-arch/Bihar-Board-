const fs = require('fs');
let code = fs.readFileSync('src/components/ui/WebsiteRatingSummary.tsx', 'utf8');
code = code.replace(
  "setRatings(data as WebsiteRating[]);",
  "setRatings(data as unknown as WebsiteRating[]);"
);
fs.writeFileSync('src/components/ui/WebsiteRatingSummary.tsx', code);

let code2 = fs.readFileSync('src/pages/admin/teacher-panel/AdminRatingsList.tsx', 'utf8');
code2 = code2.replace(
  "setRatings(data as (WebsiteRating & { id: string })[]);",
  "setRatings(data as unknown as (WebsiteRating & { id: string })[]);"
);
fs.writeFileSync('src/pages/admin/teacher-panel/AdminRatingsList.tsx', code2);
