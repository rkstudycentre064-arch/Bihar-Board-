const fs = require('fs');
let code = fs.readFileSync('src/db/users.ts', 'utf-8');

code = code.replace(
  "export async function getOrCreateUser(uid: string, email: string, name: string) {",
  "export async function getOrCreateUser(uid: string, email: string, name: string, role?: string) {"
);

code = code.replace(
  "      uid,\n      email,\n      name,\n    })",
  "      uid,\n      email,\n      name,\n      role: role || 'student',\n    })"
);

fs.writeFileSync('src/db/users.ts', code);
console.log("Patched users.ts");
