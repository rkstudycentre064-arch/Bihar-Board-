import React, { useState, useEffect } from 'react';
import { Star, Loader2, Edit2, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from './Button';
import { submitRating, getUserRating, WebsiteRating } from '../../db/ratings';
import { Link } from 'react-router';

export const WebsiteRatingForm = () => {
  const { user } = useAuth();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [review, setReview] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [existingRating, setExistingRating] = useState<WebsiteRating | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [loadingInitial, setLoadingInitial] = useState(true);

  useEffect(() => {
    if (user) {
      loadUserRating();
    } else {
      setLoadingInitial(false);
    }
  }, [user]);

  const loadUserRating = async () => {
    if (!user) return;
    try {
      const data = await getUserRating(user.uid);
      if (data) {
        setExistingRating(data);
        setRating(data.rating);
        setReview(data.review || '');
        setDisplayName(data.displayName || user.displayName || '');
      } else {
        setDisplayName(user.displayName || '');
      }
    } catch (err) {
      if (err.message && err.message.includes('offline')) {
        console.warn("Client offline, skipping rating load.");
      } else {
        console.error("Error loading rating:", err);
      }
    } finally {
      setLoadingInitial(false);
    }
  };

  const getRatingLabel = (val: number) => {
    switch (val) {
      case 1: return 'Poor';
      case 2: return 'Fair';
      case 3: return 'Good';
      case 4: return 'Very Good';
      case 5: return 'Excellent';
      default: return '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || rating === 0) return;
    setIsSubmitting(true);
    try {
      await submitRating(user.uid, {
        rating,
        review,
        displayName
      });
      setHasSubmitted(true);
      setIsEditing(false);
      await loadUserRating();
    } catch (err) {
      console.error("Error submitting rating", err);
      alert("Failed to submit rating. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loadingInitial) {
    return <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 text-blue-600 animate-spin" /></div>;
  }

  if (!user) {
    return (
      <div className="bg-white rounded-3xl p-8 text-center text-slate-900 border border-slate-100 shadow-sm">
        <h3 className="text-2xl font-bold mb-2">Rate Our Website</h3>
        <p className="text-slate-500 mb-6 max-w-md mx-auto">Please login to rate BIHAR BOARD and share your experience with us.</p>
        <div className="flex items-center justify-center gap-4">
          <Link to="/login"><Button variant="outline" className="bg-white border-slate-200 hover:bg-slate-50 text-slate-700">Login</Button></Link>
          <Link to="/register"><Button className="bg-blue-600 hover:bg-blue-500 text-white">Sign Up</Button></Link>
        </div>
      </div>
    );
  }

  if (hasSubmitted || (existingRating && !isEditing)) {
    return (
      <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-8 text-center">
        <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-8 h-8 text-emerald-600" />
        </div>
        <h3 className="text-2xl font-bold text-slate-900 mb-2">Thank you for your valuable feedback! ❤️</h3>
        <p className="text-slate-600 mb-6">Your rating has been submitted and is currently {existingRating?.status === 'APPROVED' ? 'approved' : 'pending review'}.</p>
        
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 max-w-lg mx-auto text-left mb-6">
          <div className="flex items-center gap-1 mb-3">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star key={star} className={`w-5 h-5 ${star <= (existingRating?.rating || rating) ? 'fill-amber-400 text-amber-400' : 'fill-slate-100 text-slate-200'}`} />
            ))}
            <span className="ml-2 text-sm font-bold text-slate-700">{getRatingLabel(existingRating?.rating || rating)}</span>
          </div>
          {existingRating?.review && (
            <p className="text-slate-700 italic mb-2">"{existingRating.review}"</p>
          )}
          <p className="text-sm text-slate-500">— {existingRating?.displayName}</p>
        </div>

        <Button onClick={() => setIsEditing(true)} variant="outline" className="gap-2">
          <Edit2 className="w-4 h-4" /> Edit Review
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-black text-slate-900 tracking-tight">Rate Our Website</h3>
        <p className="text-slate-500 mt-2">How would you rate your experience with BIHAR BOARD?</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex flex-col items-center gap-3">
          <div className="flex items-center gap-2 cursor-pointer">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => setRating(star)}
                className="p-1 focus:outline-none transition-transform hover:scale-110"
              >
                <Star 
                  className={`w-10 h-10 transition-colors ${
                    star <= (hoverRating || rating) 
                      ? 'fill-amber-400 text-amber-400 drop-shadow-sm' 
                      : 'fill-slate-100 text-slate-200'
                  }`} 
                />
              </button>
            ))}
          </div>
          <div className="h-6 font-bold text-amber-600">
            {getRatingLabel(hoverRating || rating)}
          </div>
        </div>

        {rating > 0 && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Write your feedback (Optional)</label>
              <textarea 
                rows={4}
                value={review}
                onChange={(e) => setReview(e.target.value)}
                placeholder="What did you like? What can we improve?"
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none resize-none"
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Display Name (Optional)</label>
              <input 
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="How should your name appear?"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div className="flex gap-3 justify-end pt-4">
              {isEditing && (
                <Button type="button" variant="ghost" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
              )}
              <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white min-w-[140px]">
                {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : (isEditing ? 'Update Rating' : 'Submit Review')}
              </Button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};
