import React, { useState, useEffect } from 'react';
import { Star, ShieldCheck, Loader2 } from 'lucide-react';
import { getPublicRatings, WebsiteRating } from '../../db/ratings';
import { format } from 'date-fns';

export const WebsiteRatingSummary = () => {
  const [ratings, setRatings] = useState<WebsiteRating[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRatings();
  }, []);

  const loadRatings = async () => {
    try {
      const data = await getPublicRatings();
      setRatings(data as unknown as WebsiteRating[]);
    } catch (err) {
      if (err.message && err.message.includes('offline')) {
        console.warn("Client offline, skipping public ratings load.");
      } else {
        console.error('Error fetching public ratings', err);
      }
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 text-blue-600 animate-spin" /></div>;
  }

  if (ratings.length === 0) {
    return null; // Don't show summary if no ratings yet
  }

  const totalRatings = ratings.length;
  const average = ratings.reduce((acc, curr) => acc + curr.rating, 0) / totalRatings;
  
  const distribution = [5, 4, 3, 2, 1].map(star => {
    const count = ratings.filter(r => r.rating === star).length;
    return {
      star,
      count,
      percentage: Math.round((count / totalRatings) * 100)
    };
  });

  return (
    <div className="bg-white rounded-3xl p-8 lg:p-12 text-slate-900 border border-slate-100 shadow-sm">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Summary Stats */}
        <div className="lg:col-span-4 flex flex-col items-center lg:items-start text-center lg:text-left">
          <h2 className="text-3xl font-black text-slate-900 mb-2">Student Reviews</h2>
          <p className="text-slate-500 mb-6">See what others are saying about BIHAR BOARD.</p>
          
          <div className="flex items-center gap-4 mb-2">
            <span className="text-6xl font-black text-amber-400">{average.toFixed(1)}</span>
            <div className="flex flex-col gap-1">
              <div className="flex text-amber-400">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star key={i} className={`w-5 h-5 ${i <= Math.round(average) ? 'fill-current' : 'fill-slate-200 text-slate-200'}`} />
                ))}
              </div>
              <span className="text-sm font-medium text-slate-500">Based on {totalRatings} rating{totalRatings !== 1 ? 's' : ''}</span>
            </div>
          </div>
        </div>

        {/* Distribution Bars */}
        <div className="lg:col-span-8 space-y-3">
          {distribution.map(dist => (
            <div key={dist.star} className="flex items-center gap-4 text-sm font-bold">
              <div className="flex items-center gap-1 w-12 text-slate-700">
                <span>{dist.star}</span> <Star className="w-4 h-4 fill-current" />
              </div>
              <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-400 rounded-full transition-all duration-1000"
                  style={{ width: `${dist.percentage}%` }}
                />
              </div>
              <div className="w-12 text-right text-slate-500">{dist.percentage}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Reviews (limit to 3) */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ratings.filter(r => r.review).slice(0, 3).map((rating, idx) => (
          <div key={idx} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
            <div className="flex text-amber-400 mb-3">
              {[1, 2, 3, 4, 5].map(i => (
                <Star key={i} className={`w-4 h-4 ${i <= rating.rating ? 'fill-current' : 'fill-slate-200 text-slate-200'}`} />
              ))}
            </div>
            <p className="text-slate-700 mb-4 text-sm leading-relaxed">"{rating.review}"</p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-900 text-blue-300 flex items-center justify-center text-xs font-bold">
                  {(rating.displayName || 'U').charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">{rating.displayName || 'User'}</p>
                  {rating.isVerifiedUser && (
                    <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Verified
                    </p>
                  )}
                </div>
              </div>
              {rating.createdAt && (
                <span className="text-xs text-slate-500">
                  {format(rating.createdAt.toDate(), 'MMM d, yyyy')}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
