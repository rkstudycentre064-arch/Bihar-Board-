import { collection, doc, addDoc, updateDoc, getDocs, getDoc, query, where, orderBy, deleteDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

export interface AIConversation {
  id: string;
  userId: string;
  title: string;
  className?: string;
  subject?: string;
  createdAt: any;
  updatedAt: any;
}

export interface AIMessage {
  id: string;
  conversationId: string;
  userId: string;
  role: 'user' | 'model';
  parts: { text: string }[];
  createdAt: any;
}

export const createAIConversation = async (userId: string, title: string, className?: string, subject?: string) => {
  const docRef = await addDoc(collection(db, 'aiConversations'), {
    userId,
    title,
    className: className || '',
    subject: subject || '',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return docRef.id;
};

export const getUserAIConversations = async (userId: string) => {
  const q = query(
    collection(db, 'aiConversations'),
    where('userId', '==', userId),
    orderBy('updatedAt', 'desc')
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AIConversation));
};

export const getAIConversationMessages = async (userId: string, conversationId: string) => {
  const q = query(
    collection(db, 'aiMessages'),
    where('conversationId', '==', conversationId),
    where('userId', '==', userId),
    orderBy('createdAt', 'asc')
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AIMessage));
};

export const addAIMessage = async (conversationId: string, userId: string, role: 'user' | 'model', text: string) => {
  const docRef = await addDoc(collection(db, 'aiMessages'), {
    conversationId,
    userId,
    role,
    parts: [{ text }],
    createdAt: serverTimestamp()
  });
  
  await updateDoc(doc(db, 'aiConversations', conversationId), {
    updatedAt: serverTimestamp()
  });
  
  return docRef.id;
};

export const deleteAIConversation = async (conversationId: string) => {
  // Frontend soft-delete or cascade delete messages
  await deleteDoc(doc(db, 'aiConversations', conversationId));
};
