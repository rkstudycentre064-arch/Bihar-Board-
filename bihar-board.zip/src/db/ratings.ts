import { db } from '../lib/firebase';
import { 
  collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, 
  query, where, orderBy, serverTimestamp 
} from 'firebase/firestore';

export interface WebsiteRating {
  userId: string;
  rating: number;
  review?: string;
  displayName?: string;
  createdAt?: any;
  updatedAt?: any;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'HIDDEN';
  isVerifiedUser: boolean;
}

// User submits or updates their rating
export async function submitRating(userId: string, data: Partial<WebsiteRating>) {
  const ratingRef = doc(db, 'websiteRatings', userId);
  const existing = await getDoc(ratingRef);
  
  if (existing.exists()) {
    await updateDoc(ratingRef, {
      ...data,
      status: 'PENDING', // Editing resets to pending
      updatedAt: serverTimestamp()
    });
  } else {
    await setDoc(ratingRef, {
      ...data,
      userId,
      status: 'PENDING',
      isVerifiedUser: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }
}

// Get user's own rating
export async function getUserRating(userId: string) {
  const ratingRef = doc(db, 'websiteRatings', userId);
  const snap = await getDoc(ratingRef);
  if (snap.exists()) {
    return snap.data() as WebsiteRating;
  }
  return null;
}

// Get all approved public ratings
export async function getPublicRatings() {
  const q = query(
    collection(db, 'websiteRatings'),
    where('status', '==', 'APPROVED'),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

// Admin functions
export async function getAllRatings() {
  const q = query(
    collection(db, 'websiteRatings'),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export async function updateRatingStatus(userId: string, status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'HIDDEN') {
  const ratingRef = doc(db, 'websiteRatings', userId);
  await updateDoc(ratingRef, {
    status,
    updatedAt: serverTimestamp()
  });
}

export async function deleteRating(userId: string) {
  const ratingRef = doc(db, 'websiteRatings', userId);
  await deleteDoc(ratingRef);
}
