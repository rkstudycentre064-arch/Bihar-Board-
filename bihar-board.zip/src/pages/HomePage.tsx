import React from 'react';
import { Link } from 'react-router';
import { Button } from '../components/ui/Button';
import { WebsiteRatingForm } from '../components/ui/WebsiteRatingForm';
import { WebsiteRatingSummary } from '../components/ui/WebsiteRatingSummary';
import { PlayCircle, BookOpen, PenTool, LayoutDashboard, Brain, ShoppingBag, ArrowRight, ShieldCheck, Award } from 'lucide-react';

export const HomePage = () => {
  return (
    <div className="flex flex-col page-background">
      {/* Hero Section */}
      <section className="hero-background pt-32 pb-24 lg:pt-40 lg:pb-32">
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="decorative-shape shape-1 animate-float"></div>
          <div className="decorative-shape shape-2 animate-float-delayed"></div>
          <div className="decorative-shape shape-3 animate-float-slow"></div>
        </div>
        <div className="container mx-auto px-4 max-w-5xl relative z-10">
          <div className="flex flex-col items-center text-center">
            
            {/* Tag */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-100 border border-slate-200 mb-8">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500"></span>
              <span className="text-xs font-bold uppercase tracking-widest text-slate-700">Official Study Ecosystem</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
              Bihar Board Preparation, <br className="hidden md:block" /> 
              <span className="text-slate-500">Redefined & Structured.</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-600 mb-12 max-w-2xl font-medium leading-relaxed">
              वीडियो, नोट्स, प्रैक्टिस, टेस्ट और रिविजन — एक ही मंच पर। The definitive digital ecosystem for Bihar Board students.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4 w-full sm:w-auto">
              <Link to="/register" className="w-full sm:w-auto">
                <Button size="lg" className="w-full sm:w-auto text-base h-14 px-10 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl">
                  Start Learning Now
                </Button>
              </Link>
              <Link to="/tests" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full sm:w-auto text-base h-14 px-10 border-2 border-slate-200 hover:bg-slate-50 rounded-2xl text-slate-700 font-semibold">
                  View Test Series
                </Button>
              </Link>
            </div>
            
            {/* Trust Indicators */}
            <div className="mt-16 flex flex-wrap items-center justify-center gap-8 md:gap-16 opacity-60 grayscale">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-6 h-6" />
                <span className="font-bold tracking-tight">Secure Platform</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-6 h-6" />
                <span className="font-bold tracking-tight">Expert Verified</span>
              </div>
              <div className="flex items-center gap-2">
                <BookOpen className="w-6 h-6" />
                <span className="font-bold tracking-tight">Complete Syllabus</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 section-light border-t border-slate-100">
        <div className="education-pattern"></div>
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="mb-16 md:mb-24">
            <h2 className="text-3xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight">Everything you need <br/> to score higher.</h2>
            <p className="text-slate-500 text-lg md:text-xl max-w-2xl font-medium leading-relaxed">
              We have structured the entire Bihar Board curriculum into smart, digestible, and interactive modules.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
            {[
              { icon: PlayCircle, title: "Smart Video Classes", desc: "Interactive video lessons strictly mapped to the BSEB syllabus.", color: "text-blue-600", bg: "bg-blue-50" },
              { icon: PenTool, title: "Online Mock Tests", desc: "Chapter-wise tests & full-length board pattern mock exams.", color: "text-emerald-600", bg: "bg-emerald-50" },
              { icon: BookOpen, title: "Premium Materials", desc: "Downloadable PDF notes, VVI questions & NCERT solutions.", color: "text-indigo-600", bg: "bg-indigo-50" },
              { icon: Brain, title: "AI Study Assistant", desc: "Get instant doubts solved 24/7 by our customized Gemini AI Tutor.", color: "text-amber-600", bg: "bg-amber-50" },
              { icon: LayoutDashboard, title: "Board Exam Mode", desc: "A special timed preparation environment mimicking the real exam.", color: "text-rose-600", bg: "bg-rose-50" },
              { icon: ShoppingBag, title: "Physical Study Store", desc: "Purchase premium printed books, notes, and question banks.", color: "text-cyan-600", bg: "bg-cyan-50" }
            ].map((feature, i) => (
              <div key={i} className="group flex flex-col items-start bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow relative z-10">
                <div className={`w-14 h-14 rounded-2xl ${feature.bg} flex items-center justify-center mb-6`}>
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600 font-medium leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Website Rating Section */}
      <section className="py-24 section-blue border-t border-slate-100">
        <div className="container mx-auto px-4 max-w-6xl space-y-16">
          <WebsiteRatingSummary />
          <WebsiteRatingForm />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 section-navy text-white">
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-20">
          <div className="decorative-shape shape-1 animate-float"></div>
          <div className="decorative-shape shape-2 animate-float-delayed"></div>
        </div>
        <div className="education-pattern opacity-10"></div>
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl md:text-5xl font-black mb-8 tracking-tight text-white">Ready for your board exams?</h2>
          <p className="text-slate-400 text-xl mb-12 font-medium max-w-2xl mx-auto">
            Join thousands of students preparing smartly for their Bihar Board examinations on our secure platform.
          </p>
          <Link to="/register">
            <Button className="bg-white text-slate-900 hover:bg-slate-100 font-bold text-lg px-10 h-14 rounded-2xl shadow-xl transition-all inline-flex items-center gap-2">
              Create Free Account <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};
