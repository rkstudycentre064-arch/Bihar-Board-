import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ChevronRight, Upload, Save, CheckCircle, ArrowLeft } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Link, useNavigate } from 'react-router';

export const AdminAddContentPage = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    shortDescription: '',
    fullDescription: '',
    type: 'PDF',
    classId: '',
    subjectId: '',
    chapterId: '',
    topicId: '',
    difficulty: 'Medium',
    isPremium: false,
    originalPrice: '',
    salePrice: '',
    status: 'DRAFT',
  });

  const handleChange = (e: any) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSave = () => {
    setLoading(true);
    // Mock save
    setTimeout(() => {
      setLoading(false);
      navigate('/admin/cms');
    }, 1500);
  };

  if (profile?.role !== 'admin' && profile?.role !== 'teacher') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }

  return (
    <div className="relative z-10 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link to="/admin/cms" className="flex items-center gap-2 text-slate-500 hover:text-blue-600 mb-6 font-medium w-fit">
          <ArrowLeft className="w-4 h-4" />
          Back to Content
        </Link>
        
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-200 bg-slate-900 text-white">
            <h1 className="text-2xl font-bold">Add New Content</h1>
            <p className="text-slate-400 text-sm mt-1">Create educational material for students.</p>
          </div>
          
          {/* Progress Steps */}
          <div className="flex border-b border-slate-200 bg-slate-50 p-4 overflow-x-auto">
            {['Basic Info', 'Classification', 'File/Media', 'Pricing', 'Review'].map((label, i) => (
              <div key={label} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold ${
                  step > i + 1 ? 'bg-emerald-500 text-white' : 
                  step === i + 1 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'
                }`}>
                  {step > i + 1 ? <CheckCircle className="w-4 h-4" /> : i + 1}
                </div>
                <span className={`ml-2 text-sm font-medium whitespace-nowrap ${step === i + 1 ? 'text-blue-700' : 'text-slate-500'}`}>
                  {label}
                </span>
                {i < 4 && <ChevronRight className="w-4 h-4 text-slate-300 mx-3" />}
              </div>
            ))}
          </div>

          <div className="p-8">
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Content Title *</label>
                  <input type="text" name="title" value={formData.title} onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="e.g. Class 10 Science Chapter 1 Notes" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Short Description</label>
                  <input type="text" name="shortDescription" value={formData.shortDescription} onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Brief summary of the content" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Content Type *</label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {['PDF', 'Video', 'MCQ', 'Notes'].map(type => (
                      <div 
                        key={type}
                        onClick={() => setFormData(prev => ({ ...prev, type }))}
                        className={`p-4 border rounded-xl cursor-pointer text-center font-medium transition ${formData.type === type ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-sm' : 'border-slate-200 hover:border-slate-300'}`}
                      >
                        {type}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Class</label>
                    <select name="classId" onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <option value="">Select Class...</option>
                      <option value="10">Class 10</option>
                      <option value="12">Class 12</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Subject</label>
                    <select name="subjectId" onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <option value="">Select Subject...</option>
                      <option value="sci">Science</option>
                      <option value="math">Mathematics</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Chapter</label>
                    <select name="chapterId" onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <option value="">Select Chapter...</option>
                      <option value="c1">Chapter 1</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Difficulty</label>
                    <select name="difficulty" value={formData.difficulty} onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <option value="Easy">Easy</option>
                      <option value="Medium">Medium</option>
                      <option value="Hard">Hard</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center bg-slate-50 hover:bg-slate-100 transition cursor-pointer">
                  <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Upload className="w-8 h-8" />
                  </div>
                  <h3 className="font-medium text-slate-900 mb-1">Click to upload file</h3>
                  <p className="text-sm text-slate-500 mb-4">PDF, MP4, or JPEG up to 50MB</p>
                  <Button variant="outline" className="mx-auto">Select File</Button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 border border-slate-200 rounded-xl bg-slate-50">
                  <div>
                    <h3 className="font-bold text-slate-900">Premium Content</h3>
                    <p className="text-sm text-slate-500">Require users to purchase this content</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" name="isPremium" checked={formData.isPremium} onChange={handleChange} className="sr-only peer" />
                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                
                {formData.isPremium && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 border border-slate-200 rounded-xl bg-white">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Original Price (₹)</label>
                      <input type="number" name="originalPrice" value={formData.originalPrice} onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="e.g. 99" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Sale Price (₹)</label>
                      <input type="number" name="salePrice" value={formData.salePrice} onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="e.g. 49" />
                    </div>
                  </div>
                )}
              </div>
            )}

            {step === 5 && (
              <div className="space-y-6">
                <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
                  <h3 className="font-bold text-slate-900 mb-4 text-lg">Review Information</h3>
                  <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-4 text-sm">
                    <div>
                      <dt className="text-slate-500">Title</dt>
                      <dd className="font-medium text-slate-900">{formData.title || '-'}</dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Type</dt>
                      <dd className="font-medium text-slate-900">{formData.type}</dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Difficulty</dt>
                      <dd className="font-medium text-slate-900">{formData.difficulty}</dd>
                    </div>
                    <div>
                      <dt className="text-slate-500">Pricing</dt>
                      <dd className="font-medium text-slate-900">{formData.isPremium ? `₹${formData.salePrice || formData.originalPrice}` : 'Free'}</dd>
                    </div>
                  </dl>
                </div>
              </div>
            )}

            <div className="mt-8 pt-6 border-t border-slate-200 flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => setStep(s => Math.max(1, s - 1))}
                disabled={step === 1}
              >
                Previous
              </Button>
              
              {step < 5 ? (
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => setStep(s => Math.min(5, s + 1))}
                >
                  Continue
                </Button>
              ) : (
                <Button 
                  className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
                  onClick={handleSave}
                  disabled={loading}
                >
                  <Save className="w-4 h-4" />
                  {loading ? 'Saving...' : 'Publish Content'}
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
