import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Plus, Search, Filter, Edit, Trash2, Eye, FileText, Video, HelpCircle, CheckCircle, Clock, Archive } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Link } from 'react-router';

export const AdminCMSPage = () => {
  const { profile } = useAuth();
  const [contents, setContents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app we'd fetch from our API
    // Mocking for now to demonstrate UI
    setTimeout(() => {
      setContents([
        { id: 1, title: 'Chapter 1: Chemical Reactions (Notes)', type: 'PDF', class: 'Class 10', subject: 'Science', status: 'PUBLISHED', price: 'Free', author: 'Rahul Sir', date: '2023-10-25' },
        { id: 2, title: 'Important Questions for Board Exam', type: 'MCQ', class: 'Class 12', subject: 'Physics', status: 'DRAFT', price: '₹49', author: 'Vikash Sir', date: '2023-10-26' },
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  if (profile?.role !== 'admin' && profile?.role !== 'teacher') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }

  return (
    <div className="relative z-10 py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Content Management</h1>
            <p className="text-slate-500">Manage study materials, videos, and tests.</p>
          </div>
          <Link to="/admin/cms/add">
            <Button className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="w-5 h-5" />
              Add Content
            </Button>
          </Link>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6 flex flex-wrap gap-4 items-center">
          <div className="relative flex-1 min-w-[250px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search content by title..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-2">
            <select className="py-2 px-4 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
              <option>All Types</option>
              <option>PDF Notes</option>
              <option>Video</option>
              <option>MCQ Test</option>
            </select>
            <select className="py-2 px-4 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
              <option>All Status</option>
              <option>Published</option>
              <option>Draft</option>
              <option>Pending Review</option>
            </select>
          </div>
        </div>

        {/* Content Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="p-4 font-medium">Title</th>
                  <th className="p-4 font-medium">Type</th>
                  <th className="p-4 font-medium">Classification</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium">Price</th>
                  <th className="p-4 font-medium">Author</th>
                  <th className="p-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr><td colSpan={7} className="p-8 text-center text-slate-500">Loading content...</td></tr>
                ) : (
                  contents.map((item: any) => (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="p-4">
                        <div className="font-medium text-slate-900">{item.title}</div>
                        <div className="text-xs text-slate-500">{item.date}</div>
                      </td>
                      <td className="p-4">
                        <span className="flex items-center gap-1.5 text-slate-600">
                          {item.type === 'PDF' && <FileText className="w-4 h-4 text-blue-500" />}
                          {item.type === 'Video' && <Video className="w-4 h-4 text-red-500" />}
                          {item.type === 'MCQ' && <HelpCircle className="w-4 h-4 text-emerald-500" />}
                          {item.type}
                        </span>
                      </td>
                      <td className="p-4 text-slate-600">
                        {item.class} • {item.subject}
                      </td>
                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1 w-fit ${
                          item.status === 'PUBLISHED' ? 'bg-emerald-100 text-emerald-700' :
                          item.status === 'DRAFT' ? 'bg-slate-100 text-slate-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {item.status === 'PUBLISHED' && <CheckCircle className="w-3 h-3" />}
                          {item.status === 'DRAFT' && <Archive className="w-3 h-3" />}
                          {item.status}
                        </span>
                      </td>
                      <td className="p-4 font-medium">{item.price}</td>
                      <td className="p-4 text-slate-600">{item.author}</td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-2">
                          <button className="p-1.5 text-slate-400 hover:text-blue-600 rounded bg-slate-50 hover:bg-blue-50 transition">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-slate-400 hover:text-amber-600 rounded bg-slate-50 hover:bg-amber-50 transition">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-slate-400 hover:text-red-600 rounded bg-slate-50 hover:bg-red-50 transition">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
