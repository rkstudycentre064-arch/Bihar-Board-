import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Loader2 } from 'lucide-react';

export const AdminOrdersPage = () => {
  const { profile } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        // fetch token via firebase auth
        const { getAuth } = await import('firebase/auth');
        const auth = getAuth();
        const t = await auth.currentUser?.getIdToken();
        
        const response = await fetch('/api/payment/admin/orders', {
          headers: {
            'Authorization': `Bearer ${t}`
          }
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch orders');
        }
        
        const data = await response.json();
        setOrders(data.orders || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    
    if (profile?.role === 'admin') {
      fetchOrders();
    } else {
      setError('Access Denied: Admins Only');
      setLoading(false);
    }
  }, [profile]);

  if (loading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin w-8 h-8" /></div>;
  if (error) return <div className="p-8 text-red-600 font-medium">{error}</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-slate-900">Admin Orders & Payments</h1>
      
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-800 font-medium border-b border-slate-200">
              <tr>
                <th className="p-4">Order ID</th>
                <th className="p-4">Provider Order ID</th>
                <th className="p-4">User ID</th>
                <th className="p-4">Amount</th>
                <th className="p-4">Status</th>
                <th className="p-4">Created At</th>
              </tr>
            </thead>
            <tbody>
              {orders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-4 text-center text-slate-500">No orders found.</td>
                </tr>
              ) : (
                orders.map((order: any) => (
                  <tr key={order.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50">
                    <td className="p-4 font-medium">{order.id}</td>
                    <td className="p-4 font-mono text-xs">{order.providerOrderId || 'N/A'}</td>
                    <td className="p-4">{order.userId}</td>
                    <td className="p-4">{order.currency} {order.totalAmount}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        order.status === 'PAID' ? 'bg-emerald-100 text-emerald-700' :
                        order.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="p-4">{new Date(order.createdAt).toLocaleString()}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
