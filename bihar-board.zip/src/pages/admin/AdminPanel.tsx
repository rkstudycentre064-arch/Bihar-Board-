import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { AdminTeacherLayout } from './teacher-panel/AdminTeacherLayout';
import { TeacherDashboard } from './teacher-panel/TeacherDashboard';
import { TeacherList } from './teacher-panel/TeacherList';
import { TeacherAdd } from './teacher-panel/TeacherAdd';
import { TeacherContent } from './teacher-panel/TeacherContent';
import { AdminRatingsList } from './teacher-panel/AdminRatingsList';

export const AdminPanel = () => {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    if (profile?.role === 'admin' && profile.uid) {
      // Sync admin status to Firestore so Security Rules pass
      setDoc(doc(db, 'admins', profile.uid), { synced: true, role: 'admin' }, { merge: true }).catch(console.error);
    }
  }, [profile]);

  if (profile?.role !== 'admin') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <TeacherDashboard />;
      case 'teachers_all':
      case 'teachers_pending':
      case 'teachers_active':
      case 'teachers_suspended':
        return <TeacherList filter={activeTab.split('_')[1]} />;
      case 'teachers_add':
        return <TeacherAdd />;
      case 'content_pending':
      case 'content_approved':
      case 'content_published':
      case 'content_rejected':
      case 'content_archived':
        return <TeacherContent filter={activeTab.split('_')[1]} />;
      case 'ratings_all':
      case 'ratings_pending':
        return <AdminRatingsList filter={activeTab.split('_')[1]} />;
      case 'settings':
        return <div className="p-8 bg-white rounded-xl shadow-sm border border-slate-200"><h2 className="text-xl font-bold mb-4">Settings</h2><p className="text-slate-500">Admin settings coming soon.</p></div>;
      default:
        return <TeacherDashboard />;
    }
  };

  return (
    <AdminTeacherLayout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </AdminTeacherLayout>
  );
};
