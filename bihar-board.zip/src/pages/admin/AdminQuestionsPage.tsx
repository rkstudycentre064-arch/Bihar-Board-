import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Plus, Search, Edit, Trash2, Eye, HelpCircle, FileDown, UploadCloud } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Link } from 'react-router';

export const AdminQuestionsPage = () => {
  const { profile } = useAuth();
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setQuestions([
        { id: 1, text: 'What is the chemical formula of Water?', type: 'MCQ', class: 'Class 10', subject: 'Science', chapter: 'Chapter 1', difficulty: 'Easy' },
        { id: 2, text: 'Explain Newton\'s Second Law of Motion.', type: 'Subjective', class: 'Class 11', subject: 'Physics', chapter: 'Chapter 5', difficulty: 'Medium' },
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  if (profile?.role !== 'admin' && profile?.role !== 'teacher') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }

  return (
    <div className="relative z-10 py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Question Bank</h1>
            <p className="text-slate-500">Manage MCQs, subjective questions, and VVI items.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2 bg-white">
              <UploadCloud className="w-4 h-4" />
              Bulk Import (CSV/JSON)
            </Button>
            <Button className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="w-5 h-5" />
              Add Question
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6 flex flex-wrap gap-4 items-center">
          <div className="relative flex-1 min-w-[250px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search questions by text or tags..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Questions Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="p-4 font-medium w-1/3">Question</th>
                  <th className="p-4 font-medium">Type</th>
                  <th className="p-4 font-medium">Classification</th>
                  <th className="p-4 font-medium">Difficulty</th>
                  <th className="p-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr><td colSpan={5} className="p-8 text-center text-slate-500">Loading questions...</td></tr>
                ) : (
                  questions.map((item: any) => (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="p-4 font-medium text-slate-900 truncate max-w-[300px]" title={item.text}>{item.text}</td>
                      <td className="p-4 text-slate-600">
                         <span className={`px-2 py-1 rounded text-xs font-bold ${item.type === 'MCQ' ? 'bg-indigo-100 text-indigo-700' : 'bg-fuchsia-100 text-fuchsia-700'}`}>
                           {item.type}
                         </span>
                      </td>
                      <td className="p-4 text-slate-600">{item.class} • {item.subject}</td>
                      <td className="p-4 text-slate-600">{item.difficulty}</td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-2">
                          <button className="p-1.5 text-slate-400 hover:text-blue-600 rounded bg-slate-50 hover:bg-blue-50 transition">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-slate-400 hover:text-red-600 rounded bg-slate-50 hover:bg-red-50 transition">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
