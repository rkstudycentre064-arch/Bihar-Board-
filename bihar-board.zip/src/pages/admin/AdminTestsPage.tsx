import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Plus, Search, Edit, Trash2, Eye, HelpCircle, CheckCircle, Clock } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Link } from 'react-router';

export const AdminTestsPage = () => {
  const { profile } = useAuth();
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setTests([
        { id: 1, title: 'Class 10 Science Mock Test 1', class: 'Class 10', subject: 'Science', duration: '60 mins', marks: 100, status: 'PUBLISHED', isPremium: false },
        { id: 2, title: 'Math Final Revision Test', class: 'Class 12', subject: 'Mathematics', duration: '180 mins', marks: 100, status: 'DRAFT', isPremium: true },
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  if (profile?.role !== 'admin' && profile?.role !== 'teacher') {
    return <div className="p-8 text-center text-red-600">Access Denied</div>;
  }

  return (
    <div className="relative z-10 py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Online Tests</h1>
            <p className="text-slate-500">Manage online tests, mock exams, and quiz assessments.</p>
          </div>
          <div className="flex gap-2">
            <Link to="/admin/cms/questions">
              <Button variant="outline" className="gap-2">
                <HelpCircle className="w-5 h-5" />
                Question Bank
              </Button>
            </Link>
            <Link to="/admin/cms/tests/add">
              <Button className="gap-2 bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="w-5 h-5" />
                Create Test
              </Button>
            </Link>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6 flex flex-wrap gap-4 items-center">
          <div className="relative flex-1 min-w-[250px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search tests..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Tests Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="p-4 font-medium">Test Title</th>
                  <th className="p-4 font-medium">Class / Subject</th>
                  <th className="p-4 font-medium">Duration</th>
                  <th className="p-4 font-medium">Marks</th>
                  <th className="p-4 font-medium">Type</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr><td colSpan={7} className="p-8 text-center text-slate-500">Loading tests...</td></tr>
                ) : (
                  tests.map((item: any) => (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="p-4 font-medium text-slate-900">{item.title}</td>
                      <td className="p-4 text-slate-600">{item.class} • {item.subject}</td>
                      <td className="p-4 text-slate-600"><Clock className="w-4 h-4 inline-block mr-1 text-slate-400"/> {item.duration}</td>
                      <td className="p-4 text-slate-600">{item.marks}</td>
                      <td className="p-4">
                        {item.isPremium ? (
                          <span className="px-2 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded-md">PAID</span>
                        ) : (
                          <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold rounded-md">FREE</span>
                        )}
                      </td>
                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1 w-fit ${
                          item.status === 'PUBLISHED' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-2">
                          <button className="p-1.5 text-slate-400 hover:text-blue-600 rounded bg-slate-50 hover:bg-blue-50 transition">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-slate-400 hover:text-amber-600 rounded bg-slate-50 hover:bg-amber-50 transition">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-slate-400 hover:text-red-600 rounded bg-slate-50 hover:bg-red-50 transition">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
