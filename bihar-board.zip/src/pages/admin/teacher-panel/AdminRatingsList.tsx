import React, { useState, useEffect } from 'react';
import { Search, Filter, CheckCircle, XCircle, Trash2, EyeOff, Loader2, Star } from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { getAllRatings, updateRatingStatus, deleteRating, WebsiteRating } from '../../../db/ratings';
import { format } from 'date-fns';

export const AdminRatingsList = ({ filter }: { filter: string }) => {
  const [search, setSearch] = useState('');
  const [ratings, setRatings] = useState<(WebsiteRating & { id: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  useEffect(() => {
    loadRatings();
  }, []);

  const loadRatings = async () => {
    try {
      const data = await getAllRatings();
      setRatings(data as unknown as (WebsiteRating & { id: string })[]);
    } catch (err) {
      console.error("Failed to load ratings:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: 'APPROVED' | 'REJECTED' | 'HIDDEN') => {
    if (!window.confirm(`Are you sure you want to mark this review as ${newStatus}?`)) return;
    setIsProcessing(id);
    try {
      await updateRatingStatus(id, newStatus);
      await loadRatings();
    } catch (err) {
      alert("Failed to update status");
    } finally {
      setIsProcessing(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to PERMANENTLY delete this rating? This action cannot be undone.")) return;
    setIsProcessing(id);
    try {
      await deleteRating(id);
      await loadRatings();
    } catch (err) {
      alert("Failed to delete rating");
    } finally {
      setIsProcessing(null);
    }
  };

  const filteredRatings = ratings.filter(r => {
    if (filter === 'pending' && r.status !== 'PENDING') return false;
    if (search && !r.displayName?.toLowerCase().includes(search.toLowerCase()) && !r.review?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
      <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by name or review content..." 
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2"><Filter className="w-4 h-4" /> Filter Ratings</Button>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto">
        {loading ? (
          <div className="p-12 flex justify-center"><Loader2 className="w-8 h-8 text-blue-600 animate-spin" /></div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
              <tr>
                <th className="p-4 font-medium">User</th>
                <th className="p-4 font-medium">Rating & Review</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium">Date</th>
                <th className="p-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRatings.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50 transition">
                  <td className="p-4">
                    <p className="font-bold text-slate-900">{item.displayName || 'Unknown User'}</p>
                    <p className="text-xs text-slate-500">ID: {item.id.slice(0, 8)}...</p>
                  </td>
                  <td className="p-4 text-slate-600 max-w-md">
                    <div className="flex items-center text-amber-400 mb-1">
                      {[1,2,3,4,5].map(i => <Star key={i} className={`w-3 h-3 ${i <= item.rating ? 'fill-current' : 'text-slate-200 fill-slate-200'}`} />)}
                    </div>
                    {item.review ? (
                      <p className="text-sm truncate" title={item.review}>"{item.review}"</p>
                    ) : (
                      <span className="text-xs text-slate-400 italic">No text review</span>
                    )}
                  </td>
                  <td className="p-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center w-fit gap-1 ${
                      item.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' :
                      item.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                      item.status === 'HIDDEN' ? 'bg-slate-100 text-slate-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="p-4 text-xs text-slate-500">
                    {item.createdAt ? format(item.createdAt.toDate(), 'MMM d, yyyy') : 'N/A'}
                  </td>
                  <td className="p-4">
                    {isProcessing === item.id ? (
                      <Loader2 className="w-5 h-5 animate-spin ml-auto text-blue-600" />
                    ) : (
                      <div className="flex items-center justify-end gap-2">
                        {item.status !== 'APPROVED' && (
                          <button onClick={() => handleStatusChange(item.id, 'APPROVED')} title="Approve" className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition"><CheckCircle className="w-4 h-4" /></button>
                        )}
                        {item.status !== 'REJECTED' && (
                          <button onClick={() => handleStatusChange(item.id, 'REJECTED')} title="Reject" className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition"><XCircle className="w-4 h-4" /></button>
                        )}
                        {item.status === 'APPROVED' && (
                          <button onClick={() => handleStatusChange(item.id, 'HIDDEN')} title="Hide" className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded transition"><EyeOff className="w-4 h-4" /></button>
                        )}
                        <button onClick={() => handleDelete(item.id)} title="Delete" className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
              {filteredRatings.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500">
                    No ratings found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
