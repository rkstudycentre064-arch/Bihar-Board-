import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { 
  LayoutDashboard, Users, UserPlus, BookOpen, FileText, 
  Settings, LogOut, CheckCircle, Clock, XCircle, Archive, Shield
} from 'lucide-react';

export const AdminTeacherLayout = ({ children, activeTab, onTabChange }: any) => {
  const { logout } = useAuth();

  const menu = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { 
      label: 'Teachers', icon: Users,
      sub: [
        { id: 'teachers_all', label: 'All Teachers' },
        { id: 'teachers_pending', label: 'Pending Approval' },
        { id: 'teachers_active', label: 'Active Teachers' },
        { id: 'teachers_suspended', label: 'Suspended Teachers' },
        { id: 'teachers_add', label: 'Add Teacher' }
      ]
    },
    {
      label: 'Teacher Content', icon: BookOpen,
      sub: [
        { id: 'content_pending', label: 'Pending Review' },
        { id: 'content_approved', label: 'Approved' },
        { id: 'content_published', label: 'Published' },
        { id: 'content_rejected', label: 'Rejected' },
        { id: 'content_archived', label: 'Archived' }
      ]
    },
    { 
      label: 'Website Ratings', icon: CheckCircle,
      sub: [
        { id: 'ratings_all', label: 'All Ratings' },
        { id: 'ratings_pending', label: 'Pending Reviews' }
      ]
    },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col hidden md:flex flex-shrink-0 shadow-xl">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-white text-lg tracking-wide">ADMIN PRO</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 uppercase tracking-wider font-semibold">Teacher Management</div>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          {menu.map((item, idx) => (
            <div key={idx} className="mb-2">
              {item.id ? (
                <button 
                  onClick={() => onTabChange(item.id)}
                  className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-slate-800 transition ${activeTab === item.id ? 'text-white border-l-4 border-blue-500 bg-slate-800' : ''}`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium text-sm">{item.label}</span>
                </button>
              ) : (
                <div className="px-6 py-2 mt-4">
                  <div className="flex items-center gap-2 mb-2 text-slate-500 uppercase text-xs font-bold tracking-wider">
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </div>
                  <div className="flex flex-col border-l border-slate-700 ml-2">
                    {item.sub?.map((subItem) => (
                      <button
                        key={subItem.id}
                        onClick={() => onTabChange(subItem.id)}
                        className={`text-left pl-4 py-2 text-sm hover:text-white transition ${activeTab === subItem.id ? 'text-white font-semibold' : 'text-slate-400'}`}
                      >
                        {subItem.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="p-4 border-t border-slate-800">
          <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition">
            <LogOut className="w-5 h-5" />
            <span className="font-medium text-sm">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 flex-shrink-0">
          <h1 className="text-xl font-bold text-slate-800">
            {
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              menu.flatMap(m => m.sub ? m.sub : [m]).find((m: any) => m.id === activeTab)?.label || 'Dashboard'
            }
          </h1>
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm">
              AD
            </div>
          </div>
        </header>
        
        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-8 bg-slate-50">
          {children}
        </div>
      </main>
    </div>
  );
};
