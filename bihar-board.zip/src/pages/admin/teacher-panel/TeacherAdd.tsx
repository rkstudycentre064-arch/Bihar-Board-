import React, { useState } from 'react';
import { Button } from '../../../components/ui/Button';
import { UserPlus, Save, Loader2 } from 'lucide-react';

export const TeacherAdd = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      alert('Teacher created successfully (mock)');
    }, 1000);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden max-w-4xl mx-auto">
      <div className="p-6 border-b border-slate-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
          <UserPlus className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">Add New Teacher</h2>
          <p className="text-sm text-slate-500">Manually create a teacher account and set permissions.</p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Full Name *</label>
            <input required type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. Anand Kumar" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Email Address *</label>
            <input required type="email" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. anand@biharboard.com" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Phone Number *</label>
            <input required type="tel" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="+91..." />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Qualification</label>
            <input type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. M.Sc. Mathematics, B.Ed." />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Primary Subject *</label>
            <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white">
              <option>Mathematics</option>
              <option>Science</option>
              <option>Social Science</option>
              <option>Hindi</option>
              <option>English</option>
              <option>Physics</option>
              <option>Chemistry</option>
              <option>Biology</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Assigned Classes *</label>
            <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white">
              <option>Class 9 & 10</option>
              <option>Class 11 & 12</option>
              <option>Class 6 to 8</option>
              <option>All Classes</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Medium</label>
            <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white">
              <option>Hindi Medium</option>
              <option>English Medium</option>
              <option>Bilingual</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Initial Status</label>
            <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white">
              <option value="PENDING">Pending (Requires Approval)</option>
              <option value="ACTIVE">Active (Can Login immediately)</option>
            </select>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-200">
          <h3 className="font-bold text-slate-900 mb-4">Permissions</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              'Create Content', 'Submit Content for Review', 
              'Create Questions', 'Create Tests', 
              'Upload Study Materials', 'Upload Videos',
              'View Own Analytics'
            ].map(perm => (
              <label key={perm} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500" />
                {perm}
              </label>
            ))}
          </div>
          <div className="mt-4 p-3 bg-blue-50 rounded-lg text-sm text-blue-800">
            <strong>Note:</strong> Teachers cannot approve their own content, manage other teachers, or access this Admin Panel.
          </div>
        </div>

        <div className="pt-6 border-t border-slate-200 flex justify-end gap-3">
          <Button type="button" variant="outline">Cancel</Button>
          <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700 text-white min-w-[120px]">
            {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'Create Teacher'}
          </Button>
        </div>
      </form>
    </div>
  );
};
