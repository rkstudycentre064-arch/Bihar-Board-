import React, { useState } from 'react';
import { Search, Filter, Eye, CheckCircle, XCircle, FileText, UploadCloud, Archive } from 'lucide-react';
import { Button } from '../../../components/ui/Button';

export const TeacherContent = ({ filter }: { filter: string }) => {
  const [search, setSearch] = useState('');

  const mockContent = [
    { id: 'CNT001', title: 'Class 10 Math Chapter 1 Notes', author: 'Ravi Kumar', type: 'PDF', status: 'PENDING', date: '2 hrs ago' },
    { id: 'CNT002', title: 'Physics Important Questions', author: 'Dr. A. Verma', type: 'Video', status: 'PUBLISHED', date: '1 day ago' },
    { id: 'CNT003', title: 'Biology Diagram Revision', author: 'Neha Singh', type: 'PDF', status: 'REJECTED', date: '3 days ago' },
  ];

  const filteredContent = mockContent.filter(c => {
    if (filter === 'pending' && c.status !== 'PENDING') return false;
    if (filter === 'published' && c.status !== 'PUBLISHED') return false;
    if (filter === 'rejected' && c.status !== 'REJECTED') return false;
    if (filter === 'archived' && c.status !== 'ARCHIVED') return false;
    if (search && !c.title.toLowerCase().includes(search.toLowerCase()) && !c.author.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
      <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by title or author..." 
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2"><Filter className="w-4 h-4" /> Filter by Type</Button>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
            <tr>
              <th className="p-4 font-medium">Content Details</th>
              <th className="p-4 font-medium">Author</th>
              <th className="p-4 font-medium">Type</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredContent.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50 transition">
                <td className="p-4">
                  <p className="font-bold text-slate-900">{item.title}</p>
                  <p className="text-xs text-slate-500">{item.id} • Submitted {item.date}</p>
                </td>
                <td className="p-4 font-medium text-slate-700">{item.author}</td>
                <td className="p-4 text-slate-600">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${item.type === 'PDF' ? 'bg-indigo-100 text-indigo-700' : 'bg-rose-100 text-rose-700'}`}>
                    {item.type}
                  </span>
                </td>
                <td className="p-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center w-fit gap-1 ${
                    item.status === 'PUBLISHED' ? 'bg-emerald-100 text-emerald-700' :
                    item.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {item.status}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center justify-end gap-2">
                    <button title="View Content" className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition"><Eye className="w-4 h-4" /></button>
                    {item.status === 'PENDING' && (
                      <>
                        <button title="Approve & Publish" className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition"><CheckCircle className="w-4 h-4" /></button>
                        <button title="Reject" className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition"><XCircle className="w-4 h-4" /></button>
                      </>
                    )}
                    {item.status === 'PUBLISHED' && (
                      <button title="Archive" className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded transition"><Archive className="w-4 h-4" /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {filteredContent.length === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-slate-500">
                  No content found matching your criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
