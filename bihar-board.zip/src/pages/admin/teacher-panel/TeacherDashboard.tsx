import React from 'react';
import { Users, UserCheck, UserX, Clock, Activity } from 'lucide-react';

export const TeacherDashboard = () => {
  const stats = [
    { label: 'Total Teachers', value: '45', icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Active Teachers', value: '38', icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { label: 'Pending Approvals', value: '5', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-100' },
    { label: 'Suspended', value: '2', icon: UserX, color: 'text-red-600', bg: 'bg-red-100' }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex items-center gap-4">
            <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${stat.bg} ${stat.color}`}>
              <stat.icon className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">{stat.label}</p>
              <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recently Added */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 lg:col-span-2 overflow-hidden">
          <div className="p-6 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-lg">Recently Added Teachers</h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-blue-200 text-blue-700 flex items-center justify-center font-bold">
                      T{i}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Dr. Sarah Sharma</h4>
                      <p className="text-xs text-slate-500">sarah@biharboard.com • Science</p>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-700">PENDING</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Activity Summary */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center gap-2">
            <Activity className="w-5 h-5 text-indigo-500" />
            <h3 className="font-bold text-slate-900 text-lg">Activity Summary</h3>
          </div>
          <div className="p-6">
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm">
                <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5" />
                <p className="text-slate-600"><strong className="text-slate-900">Ravi Kumar</strong> uploaded 2 new Video Lectures for Class 10.</p>
              </li>
              <li className="flex items-start gap-3 text-sm">
                <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                <p className="text-slate-600"><strong className="text-slate-900">Admin</strong> approved 5 Math study materials.</p>
              </li>
              <li className="flex items-start gap-3 text-sm">
                <div className="w-2 h-2 rounded-full bg-amber-500 mt-1.5" />
                <p className="text-slate-600"><strong className="text-slate-900">Neha Singh</strong> submitted Biology Test for review.</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
