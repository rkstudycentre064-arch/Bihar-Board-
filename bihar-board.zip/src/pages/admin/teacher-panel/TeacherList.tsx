import React, { useState } from 'react';
import { Search, Filter, Edit, Eye, ShieldAlert, Trash2, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '../../../components/ui/Button';

export const TeacherList = ({ filter }: { filter: string }) => {
  const [search, setSearch] = useState('');

  const mockTeachers = [
    { id: 'TCH001', name: 'Ravi Kumar', email: 'ravi@biharboard.com', subject: 'Mathematics', class: 'Class 10', status: 'ACTIVE', contentCount: 24, lastLogin: '2 hrs ago' },
    { id: 'TCH002', name: 'Neha Singh', email: 'neha@biharboard.com', subject: 'Science', class: 'Class 9', status: 'PENDING', contentCount: 0, lastLogin: 'Never' },
    { id: 'TCH003', name: 'Dr. A. Verma', email: 'averma@biharboard.com', subject: 'Physics', class: 'Class 12', status: 'SUSPENDED', contentCount: 15, lastLogin: '5 days ago' }
  ];

  const filteredTeachers = mockTeachers.filter(t => {
    if (filter === 'pending' && t.status !== 'PENDING') return false;
    if (filter === 'active' && t.status !== 'ACTIVE') return false;
    if (filter === 'suspended' && t.status !== 'SUSPENDED') return false;
    if (search && !t.name.toLowerCase().includes(search.toLowerCase()) && !t.id.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
      <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by name or ID..." 
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2"><Filter className="w-4 h-4" /> Filter</Button>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
            <tr>
              <th className="p-4 font-medium">Teacher Profile</th>
              <th className="p-4 font-medium">Subject & Class</th>
              <th className="p-4 font-medium">Content</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredTeachers.map((teacher) => (
              <tr key={teacher.id} className="hover:bg-slate-50 transition">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                      {teacher.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{teacher.name}</p>
                      <p className="text-xs text-slate-500">{teacher.id} • {teacher.email}</p>
                    </div>
                  </div>
                </td>
                <td className="p-4 text-slate-600">
                  <p className="font-medium text-slate-900">{teacher.subject}</p>
                  <p className="text-xs">{teacher.class}</p>
                </td>
                <td className="p-4 text-slate-600">
                  <span className="inline-flex items-center justify-center px-2 py-1 bg-slate-100 rounded text-xs font-bold text-slate-700">
                    {teacher.contentCount} items
                  </span>
                </td>
                <td className="p-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center w-fit gap-1 ${
                    teacher.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' :
                    teacher.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {teacher.status}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center justify-end gap-2">
                    <button title="View Profile" className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition"><Eye className="w-4 h-4" /></button>
                    {teacher.status === 'PENDING' && (
                      <button title="Approve" className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition"><CheckCircle className="w-4 h-4" /></button>
                    )}
                    {teacher.status === 'ACTIVE' && (
                      <button title="Suspend" className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition"><ShieldAlert className="w-4 h-4" /></button>
                    )}
                    <button title="Delete" className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filteredTeachers.length === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-slate-500">
                  No teachers found matching your criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
