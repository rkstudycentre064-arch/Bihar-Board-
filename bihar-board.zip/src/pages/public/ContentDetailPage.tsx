import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { FileText, Video, CheckCircle, ArrowLeft, Bookmark, AlertTriangle, Play, Download } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export const ContentDetailPage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<any>(null);
  const [hasAccess, setHasAccess] = useState(false);

  useEffect(() => {
    // Mock fetch content
    setTimeout(() => {
      setContent({
        id,
        title: 'Complete History Revision Notes',
        shortDescription: 'All important events and dates from Chapter 1 to 5.',
        fullDescription: 'These notes cover the entire syllabus in a concise and easy-to-understand format. Perfect for last-minute board exam revision.',
        type: 'PDF',
        class: 'Class 10',
        subject: 'History',
        difficulty: 'Medium',
        isPremium: true,
        salePrice: 49,
        originalPrice: 99,
        author: 'Rahul Sir',
        views: 1205,
        rating: 4.8
      });
      // Mock access check based on id
      setHasAccess(id === '2'); // Let's say id 2 is purchased
      setLoading(false);
    }, 1000);
  }, [id]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 text-slate-500">Loading content...</div>;
  }

  if (!content) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 text-red-500">Content not found.</div>;
  }

  return (
    <div className="relative z-10 py-8">
      <div className="container mx-auto px-4 max-w-5xl">
        <Link to="/study-materials" className="flex items-center gap-2 text-slate-500 hover:text-blue-600 mb-6 font-medium w-fit">
          <ArrowLeft className="w-4 h-4" />
          Back to Materials
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
              <div className="flex items-center gap-3 mb-4">
                <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold uppercase rounded-full tracking-wider">
                  {content.class}
                </span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-bold uppercase rounded-full tracking-wider">
                  {content.subject}
                </span>
              </div>
              
              <h1 className="text-3xl md:text-4xl font-black text-slate-900 mb-4 leading-tight">
                {content.title}
              </h1>
              
              <p className="text-lg text-slate-600 mb-6 font-medium">
                {content.shortDescription}
              </p>
              
              <div className="flex items-center gap-6 text-sm text-slate-500 border-t border-b border-slate-100 py-4 mb-6">
                <div className="flex items-center gap-2">
                  {content.type === 'PDF' ? <FileText className="w-5 h-5 text-blue-500" /> : <Video className="w-5 h-5 text-red-500" />}
                  <span className="font-medium text-slate-700">{content.type}</span>
                </div>
                <div>By <span className="font-medium text-slate-700">{content.author}</span></div>
                <div>{content.views} Views</div>
              </div>

              <div className="prose max-w-none text-slate-600">
                <h3 className="text-xl font-bold text-slate-900 mb-3">About this material</h3>
                <p>{content.fullDescription}</p>
              </div>
            </div>

            {/* Content Viewer / Access Gateway */}
            <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-200">
              <div className="bg-slate-900 text-white p-6 flex items-center justify-between">
                <h3 className="font-bold text-lg flex items-center gap-2">
                  {content.type === 'PDF' ? <FileText className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  Course Material
                </h3>
                {hasAccess && (
                  <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase rounded-full border border-emerald-500/30 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Unlocked
                  </span>
                )}
              </div>
              
              <div className="p-12 text-center bg-slate-50 border-t border-slate-200">
                {!content.isPremium || hasAccess ? (
                  <div className="max-w-md mx-auto">
                    <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      {content.type === 'PDF' ? <Download className="w-10 h-10" /> : <Play className="w-10 h-10 ml-2" />}
                    </div>
                    <h4 className="text-xl font-bold text-slate-900 mb-2">Ready to {content.type === 'PDF' ? 'Read' : 'Watch'}</h4>
                    <p className="text-slate-500 mb-6">Your content is unlocked and ready to access securely.</p>
                    <Button size="lg" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                      {content.type === 'PDF' ? 'Open PDF Viewer' : 'Play Video'}
                    </Button>
                  </div>
                ) : (
                  <div className="max-w-md mx-auto">
                    <div className="w-20 h-20 bg-slate-200 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-6">
                      <AlertTriangle className="w-10 h-10" />
                    </div>
                    <h4 className="text-xl font-bold text-slate-900 mb-2">Premium Content</h4>
                    <p className="text-slate-500 mb-6">You need to purchase this material to unlock full access. You can view a free preview below.</p>
                    <Button variant="outline" size="lg" className="w-full">
                      View Free Preview
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 sticky top-6">
              {content.isPremium && !hasAccess ? (
                <>
                  <div className="mb-2">
                    <span className="text-3xl font-black text-slate-900">₹{content.salePrice}</span>
                    <span className="text-lg text-slate-400 line-through ml-2">₹{content.originalPrice}</span>
                  </div>
                  <div className="text-emerald-600 font-bold text-sm mb-6">
                    Save {Math.round(((content.originalPrice - content.salePrice) / content.originalPrice) * 100)}% Today
                  </div>
                  <Link to="/store">
                    <Button size="lg" className="w-full mb-3 bg-blue-600 hover:bg-blue-700 text-white">
                      Buy Now
                    </Button>
                  </Link>
                  <p className="text-xs text-center text-slate-500 font-medium">
                    Secure checkout. Access granted instantly after verification.
                  </p>
                </>
              ) : (
                <>
                   <div className="text-center mb-6">
                     <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full mb-3">
                       <CheckCircle className="w-8 h-8" />
                     </div>
                     <h3 className="font-bold text-slate-900">You have access</h3>
                     <p className="text-sm text-slate-500">Enjoy your learning!</p>
                   </div>
                </>
              )}
              
              <div className="border-t border-slate-100 mt-6 pt-6 space-y-4">
                <Button variant="outline" className="w-full gap-2 justify-center">
                  <Bookmark className="w-4 h-4" /> Save for Later
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
