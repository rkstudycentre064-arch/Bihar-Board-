import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/ui/Button';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { getAuth } from 'firebase/auth';

export const StorePage = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Hardcoded product for demonstration
  const testProduct = {
    id: 1, // Need to make sure this product exists in DB or we seed it on backend
    title: 'Class 10 Science Crash Course (Premium)',
    price: 499,
    currency: 'INR'
  };

  const handleBuy = async () => {
    if (!user) {
      setError("Please log in to purchase.");
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');
    
    try {
      const token = await user.getIdToken();
      
      // 1. Create Pending Order
      const orderRes = await fetch('/api/payment/create-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ productId: testProduct.id })
      });
      
      if (!orderRes.ok) {
        const err = await orderRes.json();
        throw new Error(err.error || "Failed to create order");
      }
      
      const { order } = await orderRes.json();
      
      setMessage(`Order ${order.providerOrderId} created. Simulating payment...`);
      
      // 2. Simulate User Payment Provider completion and Provider Webhook
      setTimeout(async () => {
        try {
          const webhookRes = await fetch('/api/payment/webhook', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-payment-signature': 'test_signature_valid' // Placeholder signature
            },
            body: JSON.stringify({
              eventId: 'evt_' + Date.now(),
              provider: 'TEST_PROVIDER',
              providerOrderId: order.providerOrderId,
              amount: testProduct.price,
              currency: testProduct.currency,
              paymentId: 'pay_' + Date.now(),
              status: 'PAID',
              userId: user.uid
            })
          });
          
          if (!webhookRes.ok) {
             throw new Error("Webhook failed");
          }
          
          setMessage(`Payment verified! Digital access granted successfully.`);
        } catch (webhookErr: any) {
          setError(webhookErr.message);
        } finally {
          setLoading(false);
        }
      }, 2000);
      
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-slate-900">Digital Education Store</h1>
      
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900">{testProduct.title}</h2>
          <p className="text-slate-500 mt-2">Complete video lectures, premium PDF notes, and 24/7 doubt solving.</p>
          <div className="mt-4 text-2xl font-bold text-emerald-600">
            {testProduct.currency} {testProduct.price}
          </div>
        </div>
        
        <div className="flex-shrink-0">
          <Button onClick={handleBuy} disabled={loading} size="lg" className="w-full md:w-auto">
            {loading ? <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Processing...</> : 'Buy Now'}
          </Button>
        </div>
      </div>
      
      {message && (
        <div className="mt-6 p-4 bg-emerald-50 text-emerald-800 rounded-lg flex items-center border border-emerald-100">
          <CheckCircle className="w-5 h-5 mr-3 flex-shrink-0 text-emerald-500" />
          <p>{message}</p>
        </div>
      )}
      
      {error && (
        <div className="mt-6 p-4 bg-red-50 text-red-800 rounded-lg flex items-center border border-red-100">
          <AlertCircle className="w-5 h-5 mr-3 flex-shrink-0 text-red-500" />
          <p>{error}</p>
        </div>
      )}
      
    </div>
  );
};
