import React, { useState, useEffect } from 'react';
import { Search, Filter, FileText, Download, Eye, Bookmark, FileImage, ShieldAlert, Plus, X, Loader2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Link } from 'react-router';


import { useAuth } from '../../context/AuthContext';

interface Material {
  id: string;
  title: string;
  category: string;
  className: string;
  subject: string;
  language: string;
  format: 'PDF' | 'Image' | 'Video' | 'Link';
  pages: number;
  url: string;
}

export const StudyMaterialsPage = () => {
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Add Material Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newMaterial, setNewMaterial] = useState({
    title: '',
    category: 'Notes',
    className: 'Class 10',
    subject: '',
    language: 'Hindi',
    format: 'PDF',
    pages: 0,
    url: ''
  });

  const categories = ['All', 'Notes', 'Important Questions', 'Solutions', 'Previous Questions', 'Revision'];
  const classes = ['Class 9', 'Class 10', 'Class 11', 'Class 12'];
  const formats = ['PDF', 'Image', 'Video', 'Link'];

  const fetchMaterials = async () => {
    setLoading(true);
    try {
      // Mock data since backend is currently migrating
      const fetched: Material[] = [
        { id: '1', title: 'Class 10 Math Formula Sheet', category: 'Notes', className: 'Class 10', subject: 'Math', language: 'Hindi', format: 'PDF', pages: 5, url: '#' },
        { id: '2', title: 'Class 12 Physics VVI', category: 'Important Questions', className: 'Class 12', subject: 'Physics', language: 'English', format: 'PDF', pages: 12, url: '#' }
      ];
      setMaterials(fetched);
    } catch (error) {
      console.error("Error fetching materials:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMaterials();
  }, []);

  const handleAddMaterial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || profile.role !== 'admin') return;
    
    setIsSubmitting(true);
    try {
      
      // using backend API instead
      await fetch('/api/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMaterial)
      });

      setShowAddModal(false);
      setNewMaterial({
        title: '',
        category: 'Notes',
        className: 'Class 10',
        subject: '',
        language: 'Hindi',
        format: 'PDF',
        pages: 0,
        url: ''
      });
      fetchMaterials(); // refresh the list
    } catch (error) {
      console.error("Error adding material:", error);
      alert("Error adding material. Please ensure you are an admin and all fields are valid.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredMaterials = materials.filter(m => {
    const matchesCat = selectedCategory === 'All' || m.category === selectedCategory;
    const matchesSearch = m.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          m.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="relative z-10 py-8 relative">
      <div className="container mx-auto px-4 max-w-6xl space-y-8">
        
        {/* Header & Search */}
        <div className="bg-white rounded-3xl p-6 md:p-10 shadow-sm border border-slate-200">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="max-w-3xl space-y-6 flex-1">
              <div>
                <div className="inline-flex items-center justify-center px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold tracking-wider uppercase mb-3">
                  <FileText className="w-3.5 h-3.5 mr-1.5" /> Free Library
                </div>
                <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight mb-4">
                  Study Materials & Notes
                </h1>
                <p className="text-slate-600 text-lg">
                  Download high-quality PDF notes, chapter solutions, and previous year question papers.
                </p>
              </div>
              
              <div className="relative">
                <Search className="w-6 h-6 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search notes, chapters, subjects..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all outline-none text-lg font-medium"
                />
              </div>
            </div>
            
            {/* Admin Add Button */}
            {profile?.role === 'admin' && (
              <Button 
                onClick={() => setShowAddModal(true)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2 h-12 px-6 rounded-xl shadow-lg shadow-indigo-600/20"
              >
                <Plus className="w-5 h-5" /> Add Material
              </Button>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 overflow-x-auto pb-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-500 mr-2 flex-shrink-0">
            <Filter className="w-4 h-4" /> Category:
          </div>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat 
                  ? 'bg-slate-900 text-white shadow-md' 
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden min-h-[400px]">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-64 text-slate-500">
              <Loader2 className="w-8 h-8 animate-spin mb-4 text-indigo-600" />
              <p className="font-medium">Loading materials...</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredMaterials.map((material) => (
                <div key={material.id} className="p-6 hover:bg-slate-50 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-6 group">
                  
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0">
                      {material.format === 'PDF' ? <FileText className="w-6 h-6" /> : <FileImage className="w-6 h-6" />}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 mb-1 group-hover:text-indigo-600 transition-colors">
                        {material.title}
                      </h3>
                      <div className="flex flex-wrap items-center gap-3 text-xs font-semibold">
                        <span className="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">{material.className}</span>
                        <span className="text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">{material.subject}</span>
                        <span className="text-slate-500">• {material.category}</span>
                        <span className="text-slate-500">• {material.language}</span>
                        {material.pages > 0 && <span className="text-slate-500">• {material.pages} pages</span>}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 w-full md:w-auto">
                    {material.url ? (
                      <Link to={`/content/${material.id || '1'}`} className="flex-1 md:flex-none"><Button className="w-full gap-2 bg-blue-600 hover:bg-blue-700 text-white" size="sm"><Eye className="w-4 h-4" /> View Details</Button></Link>
                    ) : (
                      <Button className="flex-1 md:flex-none gap-2 bg-slate-200 text-slate-500 cursor-not-allowed" size="sm" disabled>
                        <ShieldAlert className="w-4 h-4" /> Unavailable
                      </Button>
                    )}
                  </div>
                </div>
              ))}

              {filteredMaterials.length === 0 && (
                <div className="p-16 text-center">
                  <div className="inline-flex w-16 h-16 rounded-full bg-slate-100 items-center justify-center mb-4">
                    <Search className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">No materials found</h3>
                  <p className="text-slate-500">
                    {materials.length === 0 
                      ? "No study materials have been uploaded yet." 
                      : "Try adjusting your category filter or search query."}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add Material Modal */}
      {showAddModal && profile?.role === 'admin' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-600" /> Add New Material
              </h2>
              <button 
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <form id="add-material-form" onSubmit={handleAddMaterial} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Title *</label>
                  <input 
                    type="text" 
                    required
                    value={newMaterial.title}
                    onChange={(e) => setNewMaterial({...newMaterial, title: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    placeholder="e.g. Class 10 Science Notes Chapter 1"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1">Category *</label>
                    <select 
                      value={newMaterial.category}
                      onChange={(e) => setNewMaterial({...newMaterial, category: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all bg-white"
                    >
                      {categories.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1">Class *</label>
                    <select 
                      value={newMaterial.className}
                      onChange={(e) => setNewMaterial({...newMaterial, className: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all bg-white"
                    >
                      {classes.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1">Subject *</label>
                    <input 
                      type="text" 
                      required
                      value={newMaterial.subject}
                      onChange={(e) => setNewMaterial({...newMaterial, subject: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                      placeholder="e.g. Mathematics"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1">Language *</label>
                    <select 
                      value={newMaterial.language}
                      onChange={(e) => setNewMaterial({...newMaterial, language: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all bg-white"
                    >
                      <option value="Hindi">Hindi</option>
                      <option value="English">English</option>
                      <option value="Bilingual">Bilingual</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1">Format *</label>
                    <select 
                      value={newMaterial.format}
                      onChange={(e) => setNewMaterial({...newMaterial, format: e.target.value as any})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all bg-white"
                    >
                      {formats.map(f => <option key={f} value={f}>{f}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1">Total Pages</label>
                    <input 
                      type="number" 
                      min="0"
                      value={newMaterial.pages}
                      onChange={(e) => setNewMaterial({...newMaterial, pages: parseInt(e.target.value) || 0})}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Resource URL (Google Drive, PDF link, etc.) *</label>
                  <input 
                    type="url" 
                    required
                    value={newMaterial.url}
                    onChange={(e) => setNewMaterial({...newMaterial, url: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    placeholder="https://..."
                  />
                  <p className="text-xs text-slate-500 mt-1">Provide a public link where students can view or download the material.</p>
                </div>
              </form>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAddModal(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                form="add-material-form"
                disabled={isSubmitting}
                className="bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                {isSubmitting ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
                ) : (
                  'Publish Material'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
