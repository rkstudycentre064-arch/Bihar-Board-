import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { 
  ShoppingBag, 
  Star, 
  Book, 
  FileText, 
  CheckCircle2, 
  X, 
  ShieldCheck, 
  Truck, 
  CreditCard,
  AlertCircle,
  Loader2,
  Smartphone, Lock,
  QrCode
} from 'lucide-react';
import { Link, useNavigate } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { QRCodeCanvas } from 'qrcode.react';

interface Product {
  id: number;
  title: string;
  type: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  image: string;
  icon: any;
  color: string;
}

interface CartItem {
  product: Product;
  quantity: number;
}

export const StorePage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('All Items');
  const [termsAgreed, setTermsAgreed] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  
  // Payment States
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSession, setPaymentSession] = useState<{
    orderId: number;
    paymentId: string;
    providerOrderId: string;
    amount: number;
    upiIntentUri: string;
  } | null>(null);
  const [orderCompleted, setOrderCompleted] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);

  const products: Product[] = [
    {
      id: 1,
      title: 'Class 10 Question Bank 2026 (Solved)',
      type: 'Book (Physical)',
      price: 299,
      originalPrice: 399,
      rating: 4.8,
      reviews: 124,
      image: 'bg-blue-100',
      icon: Book,
      color: 'text-blue-600'
    },
    {
      id: 2,
      title: 'Science VVI Chapter Notes + Formula PDFs',
      type: 'Digital',
      price: 99,
      originalPrice: 199,
      rating: 4.9,
      reviews: 312,
      image: 'bg-emerald-100',
      icon: FileText,
      color: 'text-emerald-600'
    },
    {
      id: 3,
      title: 'Premium Test Series (All 5 Board Subjects)',
      type: 'Digital Subscription',
      price: 499,
      originalPrice: 999,
      rating: 4.7,
      reviews: 89,
      image: 'bg-amber-100',
      icon: Star,
      color: 'text-amber-600'
    }
  ];

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((item) => item.product.id !== id));
  };

  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);
  const totalPrice = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleCheckout = async () => {
    setCheckoutError(null);
    if (!user) {
       navigate('/login?redirect=/store');
       return;
    }
    if (!termsAgreed) {
      setCheckoutError("Please accept the Terms & Conditions and Privacy Policy to place your order.");
      return;
    }

    // Save consent timestamp
    localStorage.setItem('bihar_board_terms_consent', JSON.stringify({
      accepted: true,
      date: new Date().toISOString(),
      version: "v2.4 (2026)"
    }));

    setIsProcessing(true);
    
    try {
      const token = await user.getIdToken();
      const response = await fetch('/api/payment/create-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          items: cart.map(c => ({ productId: c.product.id, quantity: c.quantity }))
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Failed to initiate payment");
      }
      
      setPaymentSession(data);
      setPaymentStatus('PENDING');

    } catch (err: any) {
      setCheckoutError(err.message || "Failed to securely initialize payment. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  // Simulate payment confirmation for dev testing (Normally webhook does this)
  const simulatePaymentSuccess = async () => {
    if (!paymentSession || !user) return;
    try {
       const token = await user.getIdToken();
       await fetch('/api/payment/simulate-webhook', {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json',
           'Authorization': `Bearer ${token}`
         },
         body: JSON.stringify({
           paymentId: paymentSession.paymentId,
           providerOrderId: paymentSession.providerOrderId,
           success: true
         })
       });
    } catch(e) {}
  };

  // Poll for payment success securely
  useEffect(() => {
    let interval: any;
    if (paymentSession && paymentStatus === 'PENDING') {
      interval = setInterval(async () => {
        try {
          if (!user) return;
          const token = await user.getIdToken();
          const response = await fetch(`/api/payment/status/${paymentSession.paymentId}`, {
            headers: { 'Authorization': `Bearer ${token}` }
          });
          const data = await response.json();
          if (data.status === 'SUCCESS') {
             setPaymentStatus('SUCCESS');
             setOrderCompleted(data.orderId || paymentSession.orderId.toString());
             setCart([]);
             clearInterval(interval);
          } else if (data.status === 'FAILED' || data.status === 'EXPIRED') {
             setPaymentStatus(data.status);
             setCheckoutError(`Payment ${data.status.toLowerCase()}. Please try again.`);
             clearInterval(interval);
          }
        } catch(e) {}
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [paymentSession, paymentStatus, user]);

  const filteredProducts = products.filter((p) => {
    if (selectedFilter === 'All Items') return true;
    if (selectedFilter === 'Books') return p.type.includes('Book');
    if (selectedFilter === 'Digital Notes') return p.type.includes('Digital');
    if (selectedFilter === 'Test Series') return p.type.includes('Subscription');
    return true;
  });

  return (
    <div className="relative z-10 py-8">
      <div className="container mx-auto px-4 max-w-6xl space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-600/20">
              <ShoppingBag className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight">BIHAR BOARD STUDY STORE</h1>
              <p className="text-slate-500 font-medium">Official verified study materials & test series.</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="w-full md:w-auto relative"
            onClick={() => setIsCartOpen(true)}
          >
            <ShoppingBag className="w-5 h-5 mr-2" />
            View Cart
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white w-6 h-6 rounded-full text-xs flex items-center justify-center font-bold border-2 border-white">
                {totalItems}
              </span>
            )}
          </Button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 overflow-x-auto pb-2">
          {['All Items', 'Books', 'Digital Notes', 'Test Series'].map((filter) => (
            <button
              key={filter}
              onClick={() => setSelectedFilter(filter)}
              className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                selectedFilter === filter
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="border-0 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col group">
              <div className={`h-48 ${product.image} flex items-center justify-center relative overflow-hidden`}>
                <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent"></div>
                <product.icon className={`w-20 h-20 ${product.color} group-hover:scale-110 transition-transform duration-500`} />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-slate-800 border border-white/20 shadow-sm">
                  {product.type}
                </div>
              </div>
              <CardHeader className="flex-1 pb-2">
                <div className="flex items-center gap-1 text-amber-500 mb-2">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-sm font-bold">{product.rating}</span>
                  <span className="text-slate-400 text-xs ml-1">({product.reviews} reviews)</span>
                </div>
                <CardTitle className="leading-tight text-xl">{product.title}</CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                <div className="flex items-end justify-between mt-4">
                  <div>
                    <span className="text-sm text-slate-400 line-through mr-2">₹{product.originalPrice}</span>
                    <span className="text-2xl font-black text-slate-900">₹{product.price}</span>
                  </div>
                  <Button 
                    onClick={() => addToCart(product)}
                    className="bg-slate-900 hover:bg-blue-700 text-white shadow-sm"
                  >
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-8 border-t border-slate-200">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
            <Truck className="w-6 h-6 text-blue-600 flex-shrink-0" />
            <div>
              <strong className="block text-slate-900">Fast Dispatch</strong>
              <span className="text-sm text-slate-500">Books ship within 24 hours. Digital instant.</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-blue-600 flex-shrink-0" />
            <div>
              <strong className="block text-slate-900">7-Day Replacement Guarantee</strong>
              <span className="text-sm text-slate-500">Defective or misprinted books replaced free.</span>
            </div>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
            <CreditCard className="w-6 h-6 text-blue-600 flex-shrink-0" />
            <div>
              <strong className="block text-slate-900">100% Secure Checkout</strong>
              <span className="text-sm text-slate-500">RBI-authorized UPI & Gateway processing.</span>
            </div>
          </div>
        </div>

      </div>

      {/* Cart & Checkout Drawer Modal */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200">
            
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50 sticky top-0 z-10">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900">Your Study Cart ({totalItems})</h3>
              </div>
              <button 
                onClick={() => { setIsCartOpen(false); setOrderCompleted(null); setCheckoutError(null); setPaymentSession(null); setPaymentStatus(null); }}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="p-4 flex-1 space-y-4 overflow-y-auto">
              
              {/* Payment Success State */}
              {orderCompleted && paymentStatus === 'SUCCESS' ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm border-4 border-white ring-1 ring-green-200">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h4 className="text-2xl font-black text-slate-900">Payment Successful!</h4>
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-left">
                    <div className="flex justify-between py-2 border-b border-slate-200">
                      <span className="text-slate-500 text-sm">Order ID</span>
                      <strong className="font-mono text-slate-900">#{orderCompleted}</strong>
                    </div>
                    <div className="flex justify-between py-2 border-b border-slate-200">
                      <span className="text-slate-500 text-sm">Payment Method</span>
                      <strong className="text-slate-900">UPI</strong>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-slate-500 text-sm">Amount Paid</span>
                      <strong className="text-green-600">₹{paymentSession?.amount}</strong>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 mt-4">
                    Your digital access is now available and physical orders are processing.
                  </p>
                  <Button onClick={() => navigate('/dashboard')} className="w-full mt-4 h-12 bg-slate-900 text-white">
                    View My Purchases
                  </Button>
                </div>

              ) : paymentSession ? (
                
                /* UPI Payment Flow State */
                <div className="py-4 space-y-6">
                  <div className="text-center">
                    <h4 className="text-xl font-bold text-slate-900">Pay Securely with UPI</h4>
                    <p className="text-slate-500 text-sm">Order #{paymentSession.providerOrderId}</p>
                  </div>

                  {/* QR Code Container */}
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center justify-center shadow-inner">
                    <p className="text-slate-500 text-sm mb-4 text-center font-medium">Scan this QR code with your UPI app</p>
                    <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100 mb-4">
                      <QRCodeCanvas 
                        value={paymentSession.upiIntentUri} 
                        size={200}
                        level={"M"}
                      />
                    </div>
                    <div className="text-3xl font-black text-slate-900">₹{paymentSession.amount}</div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="h-px bg-slate-200 flex-1"></div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">OR</span>
                    <div className="h-px bg-slate-200 flex-1"></div>
                  </div>

                  {/* Intent Button for Mobile */}
                  <div className="md:hidden">
                    <a href={paymentSession.upiIntentUri} className="block w-full">
                      <Button className="w-full h-14 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg gap-2 shadow-lg shadow-indigo-600/20 rounded-xl">
                        <Smartphone className="w-5 h-5" /> Open UPI App
                      </Button>
                    </a>
                    <p className="text-center text-xs text-slate-400 mt-3">Google Pay, PhonePe, Paytm, etc.</p>
                  </div>
                  
                  {/* Web Status Indicator */}
                  <div className="flex items-center justify-center gap-3 p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-800">
                     <Loader2 className="w-5 h-5 animate-spin flex-shrink-0" />
                     <span className="text-sm font-medium">Waiting for trusted payment confirmation...</span>
                  </div>
                  
                  {/* DEV BYPASS BUTTON - ONLY FOR TESTING */}
                  {process.env.NODE_ENV !== 'production' && (
                     <Button variant="outline" size="sm" onClick={simulatePaymentSuccess} className="w-full border-dashed border-red-300 text-red-500 hover:bg-red-50">
                        [Dev] Simulate Success Webhook
                     </Button>
                  )}

                  <div className="flex items-center justify-center gap-2 text-slate-400 text-xs">
                    <ShieldCheck className="w-4 h-4" /> Secure [UPI PAYMENT PROVIDER] Integration
                  </div>
                </div>

              ) : cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-slate-400 space-y-4">
                  <ShoppingBag className="w-16 h-16 opacity-20" />
                  <p className="font-medium text-slate-500">Your cart is empty</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div key={item.product.id} className="flex gap-4 p-4 bg-white rounded-xl border border-slate-100 shadow-sm relative pr-10">
                      <div className={`w-16 h-16 ${item.product.image} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <item.product.icon className={`w-8 h-8 ${item.product.color}`} />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 leading-tight text-sm mb-1">{item.product.title}</h4>
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-slate-500">{item.product.type}</span>
                          <span className="text-slate-300">•</span>
                          <span className="font-medium">Qty: {item.quantity}</span>
                        </div>
                        <div className="mt-2 font-black text-slate-900">₹{item.product.price}</div>
                      </div>
                      <button 
                        onClick={() => removeFromCart(item.product.id)}
                        className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors"
                        aria-label="Remove item"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Drawer Footer / Checkout */}
            {!paymentSession && !orderCompleted && cart.length > 0 && (
              <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-4 shadow-[0_-10px_20px_rgba(0,0,0,0.02)]">
                
                {/* Total */}
                <div className="flex items-center justify-between text-sm font-bold text-slate-900">
                  <span>Grand Total (GST Inc.):</span>
                  <span className="text-2xl text-blue-600 font-black">₹{totalPrice}</span>
                </div>

                {checkoutError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm flex items-start gap-2 shadow-sm shadow-red-500/5">
                    <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>{checkoutError}</span>
                  </div>
                )}

                {/* Explicit Terms Acceptance Checkbox */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-sm">
                  <label className="flex items-start gap-3 text-sm text-slate-700 cursor-pointer select-none">
                    <input 
                      type="checkbox"
                      checked={termsAgreed}
                      onChange={(e) => {
                        setTermsAgreed(e.target.checked);
                        if (e.target.checked) setCheckoutError(null);
                      }}
                      className="w-4 h-4 mt-0.5 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer flex-shrink-0"
                    />
                    <span className="leading-relaxed text-xs">
                      I accept the{' '}
                      <Link to="/terms-and-conditions" target="_blank" className="text-blue-600 font-semibold hover:underline">Terms & Conditions</Link>,{' '}
                      <Link to="/refund-policy" target="_blank" className="text-blue-600 font-semibold hover:underline">Refund Policy</Link>, and{' '}
                      <Link to="/privacy-policy" target="_blank" className="text-blue-600 font-semibold hover:underline">Privacy Policy</Link>.
                    </span>
                  </label>
                </div>

                <Button 
                  onClick={handleCheckout} 
                  disabled={isProcessing}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold h-14 text-lg shadow-lg shadow-blue-600/20 rounded-xl"
                >
                  {isProcessing ? (
                    <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Preparing Checkout...</>
                  ) : (
                    <>Pay with UPI (₹{totalPrice})</>
                  )}
                </Button>

                <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
                  <Lock className="w-3.5 h-3.5" /> 256-bit Encrypted [UPI PAYMENT PROVIDER] checkout
                </div>
              </div>
            )}
            
            {/* Payment Cancel Button */}
            {paymentSession && paymentStatus === 'PENDING' && (
              <div className="p-4 bg-slate-50 border-t border-slate-200">
                <Button 
                   variant="outline" 
                   className="w-full text-slate-600 h-12"
                   onClick={() => { setPaymentSession(null); setPaymentStatus(null); setCheckoutError("Payment cancelled."); }}
                >
                   Cancel Payment
                </Button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
