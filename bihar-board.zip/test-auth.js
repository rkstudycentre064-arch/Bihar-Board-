import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import fs from "fs";

const config = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));
const app = initializeApp(config);
const auth = getAuth(app);

async function test() {
  try {
    const res = await createUserWithEmailAndPassword(auth, "test" + Date.now() + "@example.com", "password123");
    console.log("Success:", res.user.uid);
  } catch(e) {
    console.error("Error:", e.code, e.message);
  }
}
test();
