const fs = require('fs');

let rules = fs.readFileSync('firestore.rules', 'utf8');

const websiteRatingsRules = `
    // Validation for websiteRatings
    function isValidRating(data, userId) {
      return data.keys().hasAll(['userId', 'rating', 'createdAt', 'updatedAt', 'status']) &&
             data.userId == userId &&
             data.rating is number && data.rating >= 1 && data.rating <= 5 &&
             (data.get('review', '') is string) && (data.get('review', '').size() <= 1000) &&
             (data.get('displayName', '') is string) && (data.get('displayName', '').size() <= 100) &&
             data.status in ['PENDING', 'APPROVED', 'REJECTED', 'HIDDEN'] &&
             (data.get('isVerifiedUser', false) is bool);
    }

    match /websiteRatings/{ratingId} {
      // Anyone can read APPROVED ratings. Admin can read all. Users can read their own.
      allow read: if (resource.data.status == 'APPROVED') || isAdmin() || (isSignedIn() && isOwner(resource.data.userId));
      
      // Users can create their own rating, starting as PENDING
      allow create: if isSignedIn() &&
                    isOwner(incoming().userId) &&
                    ratingId == incoming().userId && // enforce one rating per user by using their UID as document ID
                    isValidRating(incoming(), request.auth.uid) &&
                    incoming().status == 'PENDING' && // Cannot self-approve
                    incoming().createdAt == request.time &&
                    incoming().updatedAt == request.time;

      // Users can update their own rating (resetting to PENDING if they change content), Admins can update anything
      allow update: if (
                      isSignedIn() && isOwner(existing().userId) && isOwner(incoming().userId) &&
                      ratingId == incoming().userId &&
                      isValidRating(incoming(), request.auth.uid) &&
                      incoming().createdAt == existing().createdAt &&
                      incoming().updatedAt == request.time &&
                      incoming().status == 'PENDING' && // Reset to pending if edited by user
                      incoming().isVerifiedUser == existing().get('isVerifiedUser', false) // Cannot change verified status
                    ) || (
                      isAdmin() &&
                      isValidRating(incoming(), incoming().userId) &&
                      incoming().createdAt == existing().createdAt &&
                      incoming().updatedAt == request.time
                    );

      // Only admins can delete ratings
      allow delete: if isAdmin();
    }
`;

// Inject just before "match /admins/{userId}"
rules = rules.replace("    // Admins Collection", websiteRatingsRules + "\n    // Admins Collection");

fs.writeFileSync('firestore.rules', rules);
